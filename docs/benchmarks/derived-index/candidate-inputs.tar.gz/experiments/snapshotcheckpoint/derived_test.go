//go:build darwin || linux

package snapshotcheckpoint

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/lydakis/errand/internal/snapshot"
)

func derivedOracle(t *testing.T, root, cache string, journal bool) Result {
	t.Helper()
	got, err := PrepareDerived(t.Context(), root, cache, snapshot.SelectOptions{}, journal)
	if err != nil || got.CacheError != "" {
		t.Fatalf("derived: %+v %v", got, err)
	}
	want, err := Cold(t.Context(), root, snapshot.SelectOptions{})
	if err != nil {
		t.Fatal(err)
	}
	a, err := got.State.RootHash(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	b, err := want.State.RootHash(t.Context())
	if err != nil || a != b {
		t.Fatalf("roots differ %s %s %v", a, b, err)
	}
	return got
}

func TestDerivedRestartJournalCompactionAndRecovery(t *testing.T) {
	for _, journal := range []bool{false, true} {
		t.Run(fmt.Sprint(journal), func(t *testing.T) {
			root, cache := fixture(t)
			seed := derivedOracle(t, root, cache, journal)
			if !seed.Written || seed.Hashed != 3 {
				t.Fatalf("seed %+v", seed)
			}
			warm := derivedOracle(t, root, cache, journal)
			if warm.Written || warm.Reused != 3 {
				t.Fatalf("warm %+v", warm)
			}
			for i := 0; i < maxJournalRecords+1; i++ {
				if err := os.WriteFile(filepath.Join(root, "a"), []byte(fmt.Sprint(i)), 0600); err != nil {
					t.Fatal(err)
				}
				got := derivedOracle(t, root, cache, journal)
				if !got.Written || got.Hashed != 1 || got.Reused != 2 {
					t.Fatalf("edit %+v", got)
				}
				if journal && i == maxJournalRecords && !got.Compacted {
					t.Fatal("journal did not compact")
				}
			}
			if err := os.Remove(filepath.Join(root, "a")); err != nil {
				t.Fatal(err)
			}
			if err := os.Mkdir(filepath.Join(root, "nested"), 0700); err != nil {
				t.Fatal(err)
			}
			if err := os.Symlink("../b", filepath.Join(root, "nested", "link")); err != nil {
				t.Fatal(err)
			}
			derivedOracle(t, root, cache, journal)
			// A torn trailing transaction cannot hide the last verified generation.
			f, err := os.OpenFile(filepath.Join(cache, "index"), os.O_WRONLY|os.O_APPEND, 0600)
			if err != nil {
				t.Fatal(err)
			}
			f.Write([]byte("partial frame"))
			f.Close()
			got := derivedOracle(t, root, cache, journal)
			if got.CacheStatus != "recovered" || !got.Compacted || !got.Written {
				t.Fatalf("recovery %+v", got)
			}
			got = derivedOracle(t, root, cache, journal)
			if got.CacheStatus != "hit" || got.Written {
				t.Fatalf("recovered warm %+v", got)
			}
		})
	}
}

func TestDerivedLargeTreeAndStaleWriter(t *testing.T) {
	root, cache := fixture(t)
	root, _ = filepath.EvalSymlinks(root)
	for i := 0; i < 4200; i++ {
		if err := os.WriteFile(filepath.Join(root, fmt.Sprintf("f%05d", i)), []byte("x"), 0600); err != nil {
			t.Fatal(err)
		}
	}
	derivedOracle(t, root, cache, true)
	if got := derivedOracle(t, root, cache, true); got.CacheStatus != "hit" || got.Hashed != 0 {
		t.Fatalf("large restart: %+v", got)
	}
	_, _, policy, _, err := snapshot.SelectFilesGuarded(root, snapshot.SelectOptions{})
	if err != nil {
		t.Fatal(err)
	}
	key, err := checkoutIdentity(root, policy, snapshot.SelectOptions{})
	if err != nil {
		t.Fatal(err)
	}
	old, status, _, err := readDerived(t.Context(), cache, key)
	if err != nil || status != "hit" {
		t.Fatalf("load %s %v", status, err)
	}
	if err := os.WriteFile(filepath.Join(root, "f00000"), []byte("y"), 0600); err != nil {
		t.Fatal(err)
	}
	got := derivedOracle(t, root, cache, true)
	if got.Hashed != 1 || got.CheckpointBytes >= 10000 {
		t.Fatalf("not a small journal append: %+v", got)
	}
	verified := verifiedFixture(t, root)
	before, _ := os.ReadFile(filepath.Join(cache, "index"))
	if _, _, err := writeDerived(t.Context(), cache, key, verified, got.State, old, true); err == nil {
		t.Fatal("stale writer appended")
	}
	after, _ := os.ReadFile(filepath.Join(cache, "index"))
	if string(before) != string(after) {
		t.Fatal("stale writer changed checkpoint")
	}
	ctx, cancel := context.WithCancel(t.Context())
	cancel()
	if _, err := PrepareDerived(ctx, root, cache, snapshot.SelectOptions{}, true); err != context.Canceled {
		t.Fatal(err)
	}
	derivedOracle(t, root, cache, true)
}

func TestDerivedRejectsInvalidPublicationAndCorruptBase(t *testing.T) {
	root, cache := fixture(t)
	got := derivedOracle(t, root, cache, true)
	if _, _, err := writeDerived(t.Context(), cache, identity{Root: root}, snapshot.VerifiedObservations{}, got.State, loadedCheckpoint{}, false); err == nil {
		t.Fatal("accepted invalid batch")
	}
	file := filepath.Join(cache, "index")
	data, err := os.ReadFile(file)
	if err != nil {
		t.Fatal(err)
	}
	data[len(data)/2] ^= 1
	if err := os.WriteFile(file, data, 0600); err != nil {
		t.Fatal(err)
	}
	got = derivedOracle(t, root, cache, true)
	if got.CacheStatus != "corrupt" || got.Reused != 0 {
		t.Fatalf("corruption reused: %+v", got)
	}
}

func TestDerivedBusyCacheStillReturnsFreshSnapshot(t *testing.T) {
	root, cache := fixture(t)
	derivedOracle(t, root, cache, true)
	lock, err := derivedLock(cache, true)
	if err != nil {
		t.Fatal(err)
	}
	defer unlockDerived(lock)
	got, err := PrepareDerived(t.Context(), root, cache, snapshot.SelectOptions{}, true)
	if err != nil || got.State == nil || got.Reused != 0 || got.Hashed != 3 || got.Written || got.CacheError == "" {
		t.Fatalf("busy cache blocked fresh result: %+v %v", got, err)
	}
}

func TestJournalCoalescesObservationEditsAcrossRestarts(t *testing.T) {
	root, cache := fixture(t)
	derivedOracle(t, root, cache, true)
	// Both a preexisting entry and a journal-only entry are deleted, recreated
	// with different metadata, and deleted again before any compaction.
	for _, name := range []string{"a", "new"} {
		file := filepath.Join(root, name)
		for step := 0; step < 6; step++ {
			var err error
			if step%2 == 0 {
				err = os.WriteFile(file, []byte(fmt.Sprint(name, step)), 0600)
			} else {
				err = os.Remove(file)
			}
			if err != nil {
				t.Fatal(err)
			}
			got := derivedOracle(t, root, cache, true)
			if got.CacheStatus != "hit" || !got.Written || got.Compacted {
				t.Fatalf("unexpected rebuild: %+v", got)
			}
		}
	}
	got := derivedOracle(t, root, cache, true)
	if got.Written || got.Hashed != 0 {
		t.Fatalf("replayed state was not reusable: %+v", got)
	}
}
