// Package manifest owns immutable, validated source metadata. It does not grant
// selection authority or certify that live files still match the snapshot.
package manifest

import (
	"context"
	"fmt"
	"github.com/lydakis/errand/internal/archive"
	"github.com/lydakis/errand/internal/proto"
	"math"
	"path"
	"slices"
	"sort"
	"strings"
	"sync"
)

// Edit replaces or deletes one exact path. Descendant deletions are explicit.
// Update applies the whole batch before checking hierarchy and byte totals.
type Edit struct {
	Entry  proto.ManifestEntry
	Delete bool
}

// Snapshot owns a strictly sorted inventory. Updates copy contiguous unchanged
// ranges and validate only replacements against the final hierarchy. Metadata
// never mutates; the derived wire identity is synchronized and cached.
type Snapshot struct {
	entries  []proto.ManifestEntry
	size     int64
	mu       sync.Mutex
	wireRoot string
}

func New(ctx context.Context, m proto.Manifest) (*Snapshot, error) {
	if err := archive.ValidateSortedContext(ctx, m); err != nil {
		return nil, err
	}
	var size int64
	for _, e := range m.Entries {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if e.Path == "." {
			return nil, fmt.Errorf("manifest path must not name the root")
		}
		if e.Size > math.MaxInt64-size {
			return nil, fmt.Errorf("manifest byte total overflows")
		}
		size += e.Size
	}
	s := &Snapshot{entries: slices.Clone(m.Entries), size: size}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return s, nil
}
func (s *Snapshot) Bytes() int64 { return s.size }
func (s *Snapshot) Len() int     { return len(s.entries) }
func (s *Snapshot) Lookup(name string) (proto.ManifestEntry, bool) {
	i, ok := slices.BinarySearchFunc(s.entries, name, func(e proto.ManifestEntry, p string) int { return strings.Compare(e.Path, p) })
	if ok {
		return s.entries[i], true
	}
	return proto.ManifestEntry{}, false
}

// Walk visits sorted entries. Returning false stops successfully.
func (s *Snapshot) Walk(ctx context.Context, visit func(proto.ManifestEntry) bool) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	for _, e := range s.entries {
		if err := ctx.Err(); err != nil {
			return err
		}
		if !visit(e) {
			break
		}
	}
	return ctx.Err()
}

// Subtree visits the exact root first, then all its descendants, including
// descendants of implicit roots. Callers use Walk for the entire inventory.
func (s *Snapshot) Subtree(ctx context.Context, root string, visit func(proto.ManifestEntry) bool) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	if e, ok := s.Lookup(root); ok && !visit(e) {
		return ctx.Err()
	}
	lo, hi := root+"/", root+"0"
	i := sort.Search(len(s.entries), func(i int) bool { return s.entries[i].Path >= lo })
	for ; i < len(s.entries) && s.entries[i].Path < hi; i++ {
		if err := ctx.Err(); err != nil {
			return err
		}
		if !visit(s.entries[i]) {
			break
		}
	}
	return ctx.Err()
}

// Manifest returns an owned export, preserving nil versus empty wire identity.
func (s *Snapshot) Manifest(ctx context.Context) (proto.Manifest, error) {
	if err := ctx.Err(); err != nil {
		return proto.Manifest{}, err
	}
	m := proto.Manifest{Entries: slices.Clone(s.entries)}
	if err := ctx.Err(); err != nil {
		return proto.Manifest{}, err
	}
	return m, nil
}

// RootHash retains the existing JSON wire identity. Cancellation is checked
// before and after serialization; encoding/json itself cannot be interrupted.
func (s *Snapshot) RootHash(ctx context.Context) (string, error) {
	if err := ctx.Err(); err != nil {
		return "", err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := ctx.Err(); err != nil {
		return "", err
	}
	if s.wireRoot == "" {
		root := (proto.Manifest{Entries: s.entries}).RootHash()
		if err := ctx.Err(); err != nil {
			return "", err
		}
		s.wireRoot = root
	}
	return s.wireRoot, nil
}
func (s *Snapshot) Update(ctx context.Context, edits []Edit) (*Snapshot, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if len(edits) == 0 {
		return s, nil
	}
	ordered := slices.Clone(edits)
	slices.SortFunc(ordered, func(a, b Edit) int { return strings.Compare(a.Entry.Path, b.Entry.Path) })
	var replacements proto.Manifest
	size, count := s.size, len(s.entries)
	changed := false
	for i, e := range ordered {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		p := e.Entry.Path
		if p == "" || p == "." || path.Clean(p) != p || strings.HasPrefix(p, "/") || strings.HasPrefix(p, "../") || p == ".." || strings.ContainsRune(p, 0) {
			return nil, fmt.Errorf("unsafe edit path")
		}
		if i > 0 && ordered[i-1].Entry.Path == p {
			return nil, fmt.Errorf("duplicate edit path")
		}
		if old, ok := s.Lookup(p); ok {
			size -= old.Size
			changed = changed || e.Delete || old != e.Entry
			if e.Delete {
				count--
			}
		} else if !e.Delete {
			changed = true
			count++
		}
		if !e.Delete {
			replacements.Entries = append(replacements.Entries, e.Entry)
		}
	}
	if err := archive.ValidateSortedContext(ctx, replacements); err != nil {
		return nil, err
	}
	if !changed {
		return s, nil
	}
	for _, e := range replacements.Entries {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if e.Size > math.MaxInt64-size {
			return nil, fmt.Errorf("manifest byte total overflows")
		}
		size += e.Size
	}
	// Deleting to empty uses the checkpoint's canonical nil representation.
	// A semantic no-op returned above preserves its original wire representation.
	var entries []proto.ManifestEntry
	if count > 0 {
		entries = make([]proto.ManifestEntry, 0, count)
	}
	cursor := 0
	for _, edit := range ordered {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		i := cursor + sort.Search(len(s.entries)-cursor, func(i int) bool { return s.entries[cursor+i].Path >= edit.Entry.Path })
		entries = append(entries, s.entries[cursor:i]...)
		cursor = i
		if cursor < len(s.entries) && s.entries[cursor].Path == edit.Entry.Path {
			cursor++
		}
		if !edit.Delete {
			entries = append(entries, edit.Entry)
		}
	}
	entries = append(entries, s.entries[cursor:]...)
	next := &Snapshot{entries: entries, size: size}
	for _, e := range replacements.Entries {
		for parent := path.Dir(e.Path); parent != "."; parent = path.Dir(parent) {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
			if p, ok := next.Lookup(parent); ok && p.Type != proto.EntryDir {
				return nil, fmt.Errorf("manifest path passes through non-directory %q", parent)
			}
		}
		if e.Type != proto.EntryDir {
			descendant := false
			if err := next.Subtree(ctx, e.Path, func(child proto.ManifestEntry) bool { descendant = child.Path != e.Path; return !descendant }); err != nil {
				return nil, err
			}
			if descendant {
				return nil, fmt.Errorf("manifest non-directory %q has descendants", e.Path)
			}
		}
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return next, nil
}

// Diff returns sorted exact edits using a linear merge of the inventories.
func (s *Snapshot) Diff(ctx context.Context, next *Snapshot) ([]Edit, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if s == next {
		return nil, nil
	}
	before, after := proto.Manifest{Entries: s.entries}, proto.Manifest{Entries: next.entries}
	var result []Edit
	i, j := 0, 0
	for i < len(before.Entries) || j < len(after.Entries) {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		switch {
		case j == len(after.Entries) || i < len(before.Entries) && before.Entries[i].Path < after.Entries[j].Path:
			result = append(result, Edit{Entry: before.Entries[i], Delete: true})
			i++
		case i == len(before.Entries) || after.Entries[j].Path < before.Entries[i].Path:
			result = append(result, Edit{Entry: after.Entries[j]})
			j++
		default:
			if before.Entries[i] != after.Entries[j] {
				result = append(result, Edit{Entry: after.Entries[j]})
			}
			i++
			j++
		}
	}
	return result, nil
}
