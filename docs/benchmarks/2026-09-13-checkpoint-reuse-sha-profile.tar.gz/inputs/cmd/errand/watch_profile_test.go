package main

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime/pprof"
	"runtime/trace"
	"testing"
 changeops "github.com/lydakis/errand/internal/changes"
)

func startWatchProfile(b *testing.B) func() {
	dir := os.Getenv("ERRAND_BENCH_PROFILE_DIR")
	if dir == "" {
		return nil
	}
	cpu, err := os.Create(filepath.Join(dir, fmt.Sprintf("cpu-%d.pprof", b.N)))
	if err != nil {
		b.Fatal(err)
	}
	tr, err := os.Create(filepath.Join(dir, fmt.Sprintf("trace-%d.out", b.N)))
	if err != nil {
		b.Fatal(err)
	}
	if err := pprof.StartCPUProfile(cpu); err != nil {
		b.Fatal(err)
	}
	if err := trace.Start(tr); err != nil {
		b.Fatal(err)
	}
	changeops.ResetCheckpointProbe()
 return func() { trace.Stop(); pprof.StopCPUProfile(); tr.Close(); cpu.Close(); reads,hits := changeops.CheckpointProbe(); fmt.Printf("CHECKPOINT_READS=%d HITS=%d\n",reads,hits) }
}
