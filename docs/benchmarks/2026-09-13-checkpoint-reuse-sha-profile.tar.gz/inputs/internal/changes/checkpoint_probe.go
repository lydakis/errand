package changes
import "sync/atomic"
var checkpointProbeReads, checkpointProbeHits atomic.Int64
func ResetCheckpointProbe() { checkpointProbeReads.Store(0); checkpointProbeHits.Store(0) }
func CheckpointProbe() (int64, int64) { return checkpointProbeReads.Load(), checkpointProbeHits.Load() }
