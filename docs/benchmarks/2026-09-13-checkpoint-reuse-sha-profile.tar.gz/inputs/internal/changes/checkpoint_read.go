package changes

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
)

// One decoded revision per checkpoint/session, owned under the caller's transfer
// lock. Reuse never certifies live destination files. Every access still opens
// the guarded storage and reads the bounded regular record in full. Exact-byte
// hashing detects in-place edits even when size and timestamps are restored.
// No global cache, timestamp shortcut, or durability barrier is involved.
type checkpointReadCache struct {
	digest [sha256.Size]byte
	state  *checkpointState
}

func (c *TransferCheckpoint) read(root *os.Root, name string) (checkpointState, error) {
	checkpointProbeReads.Add(1)
	raw, err := readTransferRecordBytes(root, name)
	if err != nil {
		return checkpointState{}, err
	}
	digest := sha256.Sum256(raw)
	if c.cache != nil && c.cache.state != nil && c.cache.digest == digest {
		checkpointProbeHits.Add(1)
		state := *c.cache.state
		return state, c.validateRelationship(state)
	}
	var state checkpointState
	if err := json.Unmarshal(raw, &state); err != nil {
		return state, err
	}
	if err := c.validateRelationship(state); err != nil {
		return state, err
	}
	if _, err := hex.DecodeString(state.InitialRoot); err != nil || len(state.InitialRoot) != 64 {
		return state, fmt.Errorf("invalid checkpoint creation digest")
	}
	if err := validateCheckpointManifest(state.Manifest); err != nil {
		return state, err
	}
	state.manifestRoot = state.Manifest.RootHash()
	if state.Revision == 0 {
		if state.manifestRoot != state.InitialRoot || state.LastReceipt != "" || state.LastRequest != "" {
			return state, fmt.Errorf("invalid initial checkpoint")
		}
	} else if _, err := hex.DecodeString(state.LastRequest); err != nil || len(state.LastRequest) != 64 || !filepath.IsAbs(state.LastReceipt) {
		return state, fmt.Errorf("invalid checkpoint application identity")
	}
	if c.cache == nil {
		c.cache = &checkpointReadCache{}
	}
	*c.cache = checkpointReadCache{digest: digest, state: &state}
	return state, nil
}

func (c *TransferCheckpoint) validateRelationship(state checkpointState) error {
	if state.Version != 1 || state.Owner != c.Owner || state.SourceID != c.SourceID || state.RootID != c.RootID {
		return fmt.Errorf("checkpoint does not match its recorded relationship")
	}
	return nil
}
