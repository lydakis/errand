import json, os, subprocess
from pathlib import Path
out=Path('../results').resolve()
out.mkdir()
(out/'fixtures').mkdir()
env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0',TMPDIR=str(out/'fixtures'),ERRAND_BENCH_PROFILE_DIR=str(out))
def run(args,name,binary=False):
 p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (out/name).write_bytes(p.stdout)
 (out/(name+'.stderr')).write_bytes(p.stderr)
 if p.returncode: raise RuntimeError((args,p.returncode,p.stderr.decode()))
bin=out/'errand.test'
run(['go','version'],'go.txt')
run(['stat','-f','-c','%T',str(out)],'filesystem.txt')
run(['go','test','-c','-o',str(bin),'./cmd/errand'],'build.txt')
run([str(bin),'-test.run=^$','-test.bench=^BenchmarkWatchPhases$','-test.benchtime=20x','-test.timeout=10m'],'benchmark.txt')
run(['go','tool','trace','-pprof=syscall',str(out/'trace-20.out')],'syscall.pprof')
run(['go','tool','pprof','-top','-nodecount=30',str(bin),str(out/'cpu-20.pprof')],'cpu-top.txt')
run(['go','tool','pprof','-top','-cum','-nodecount=30',str(bin),str(out/'cpu-20.pprof')],'cpu-cumulative.txt')
run(['go','tool','pprof','-top','-nodecount=30',str(bin),str(out/'syscall.pprof')],'syscall-top.txt')
run(['go','tool','pprof','-top','-cum','-nodecount=30',str(bin),str(out/'syscall.pprof')],'syscall-cumulative.txt')
bin.unlink()
print('Watch-loop CPU and syscall profiles complete',flush=True)
