import unittest

from benchmark_observation_journal import validate_sample


class JournalCampaignReceipts(unittest.TestCase):
    def test_compaction_and_history_recovery_cannot_silently_fall_back(self):
        for scenario, edits, records in (("records", 1, 32), ("bytes", 60, 1), ("recovery", 0, 4)):
            result = dict(Hashed=edits, Reused=100-edits, Written=True, CacheError="",
                          CacheStatus="recovered" if scenario == "recovery" else "hit",
                          ReplacedBase=True, JournalRecordsLoaded=records)
            validate_sample({"Result": result}, 100, edits, scenario, "observation-journal")
            for key, value in (("ReplacedBase", False), ("JournalRecordsLoaded", 0),
                               ("Hashed", 100), ("CacheStatus", "missing"), ("CacheError", "skipped")):
                with self.subTest(scenario=scenario, key=key), self.assertRaises(RuntimeError):
                    validate_sample({"Result": dict(result, **{key: value})},
                                    100, edits, scenario, "observation-journal")


if __name__ == "__main__":
    unittest.main()
