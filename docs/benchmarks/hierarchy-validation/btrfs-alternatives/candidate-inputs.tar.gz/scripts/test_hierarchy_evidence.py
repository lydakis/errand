import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from hierarchy_inputs import require_production_diff, verify_baseline


class EvidenceContracts(unittest.TestCase):
    def test_source_gate_rejects_unrelated_changes_and_wrong_baseline(self):
        with tempfile.TemporaryDirectory() as tmp:
            a, b = Path(tmp)/'a', Path(tmp)/'b'
            for root in (a, b):
                (root/'internal/manifest').mkdir(parents=True)
                (root/'internal/manifest/snapshot.go').write_text('baseline')
                (root/'other.go').write_text('same')
            (b/'internal/manifest/snapshot.go').write_text('candidate')
            self.assertEqual(set(require_production_diff(a, b)), {'internal/manifest/snapshot.go'})
            (b/'other.go').write_text('unrelated')
            with self.assertRaisesRegex(RuntimeError, 'other.go'):
                require_production_diff(a, b)
            archive = Path(tmp)/'baseline.tar.gz'
            archive.write_bytes(b'wrong archive')
            with self.assertRaisesRegex(RuntimeError, 'baseline archive'):
                verify_baseline(archive)

    def test_renderers_reject_invalid_reports_under_optimized_python(self):
        evidence = Path(__file__).resolve().parents[1]/'docs/benchmarks/hierarchy-validation'
        for renderer, campaign in (('summarize.py', 'apfs-final'), ('summarize_controls.py', 'btrfs-controls')):
            original = json.loads((evidence/campaign/'report.json').read_text())
            for defect in ('status', 'duplicate', 'receipt'):
                if renderer == 'summarize_controls.py' and defect == 'receipt':
                    continue
                report = json.loads(json.dumps(original))
                if defect == 'status':
                    report['status'] = 'failed'
                elif defect == 'duplicate':
                    key = 'commands' if renderer == 'summarize.py' else 'samples'
                    report[key][1] = report[key][0]
                else:
                    report['samples'][0]['Hash'] = 'wrong root'
                with self.subTest(renderer=renderer, defect=defect), tempfile.TemporaryDirectory() as tmp:
                    root = Path(tmp)
                    (root/'candidate-inputs.tar.gz').symlink_to(evidence/campaign/'candidate-inputs.tar.gz')
                    (root/'report.json').write_text(json.dumps(report))
                    result = subprocess.run([sys.executable, '-O', str(evidence/renderer), str(root/'report.json')],
                                            capture_output=True, text=True)
                    self.assertNotEqual(result.returncode, 0, result.stdout)
                    self.assertIn('RuntimeError', result.stderr)


if __name__ == '__main__':
    unittest.main()
