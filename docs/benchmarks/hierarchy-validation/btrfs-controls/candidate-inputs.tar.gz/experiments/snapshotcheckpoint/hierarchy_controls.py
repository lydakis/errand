#!/usr/bin/env python3
"""Focused A/A/B check of Linux mixed-update and ephemeral-fetch timing signals."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import tarfile

sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'scripts'))
from benchmark_checkpoint_builder import candidate_digest
from benchmark_snapshot_integration import benchmark_campaign, benchmark_order, filesystem, parse_sample, run
from snapshot_provenance import comparison_inputs, harness_inputs, require_matching_inputs


def main():
    source,out=Path.cwd(),Path(sys.argv[1]).resolve()
    out.mkdir(parents=True,exist_ok=False)
    env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0')
    for key in tuple(env):
        if key.startswith('GIT_'): del env[key]
    env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull)
    archive=source/'docs/benchmarks/hierarchy-validation/baseline-inputs.tar.gz'
    report=dict(scope=__doc__,rounds=12,platform=platform.platform(),samples=[],
                source_sha256=candidate_digest(source,out),harness_inputs=harness_inputs(source/'scripts'),
                driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                baseline_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
    with tarfile.open(out/'candidate-inputs.tar.gz','w:gz') as tar:
        paths=[*source.rglob('*.go'),source/'go.mod',source/'go.sum',*(source/'scripts').glob('*.py'),Path(__file__).resolve()]
        for p in sorted(p for p in paths if not p.is_relative_to(out)):
            tar.add(p,arcname=str(p.relative_to(source)),recursive=False)
    report['candidate_archive_sha256']=hashlib.sha256((out/'candidate-inputs.tar.gz').read_bytes()).hexdigest()
    with benchmark_campaign(out,report) as scratch:
        env['TMPDIR']=str(scratch)
        report['filesystem']=filesystem(scratch,env,out,'filesystem')
        if report['filesystem'].lower()!='btrfs': raise RuntimeError('Btrfs control required')
        report['mount']=run(['findmnt','-T',str(scratch),'-n','-o','FSTYPE,OPTIONS'],source,env,out/'mount.txt')
        baseline=scratch/'baseline'; baseline.mkdir()
        with tarfile.open(archive) as tar: tar.extractall(baseline,filter='data')
        added=Path('internal/manifest/hierarchy_update_test.go')
        shutil.copyfile(source/added,baseline/added)
        current={p:h for p,h in comparison_inputs(source).items() if not (source/p).is_relative_to(out)}
        require_matching_inputs(dict(baseline=comparison_inputs(baseline),candidate=current),[])
        report['comparison_inputs']=current
        cases={
            'mixed-1000':('./internal/manifest','^BenchmarkHierarchyUpdate$/^1000$/^mixed$','1s'),
            'mixed-10000':('./internal/manifest','^BenchmarkHierarchyUpdate$/^10000$/^mixed$','1s'),
            'dispersed-1000':('./internal/manifest','^BenchmarkHierarchyUpdate$/^1000$/^dispersed$','1s'),
            'fetch-false':('./cmd/errand','^BenchmarkFetchCompletion$/^persistent=false$','5x'),
        }
        report['cases'],report['toolchains'],report['binaries']=cases,{},{}
        binaries={}
        for build,root in (('baseline',baseline),('candidate',source)):
            report['toolchains'][build]=json.loads(run(['go','env','-json','GOVERSION','GOOS','GOARCH','CGO_ENABLED','GOFLAGS','GOTOOLCHAIN','GOEXPERIMENT'],root,env,out/f'{build}-toolchain.json'))
            for package in sorted({c[0] for c in cases.values()}):
                key=package.removeprefix('./').replace('/','-')
                binary=scratch/f'{build}-{key}.test'
                run(['go','test','-c','-o',str(binary),package],root,env,out/f'{build}-{key}-build.txt')
                binaries[build,package]=binary
                report['binaries'][build+'-'+key]=hashlib.sha256(binary.read_bytes()).hexdigest()
        assert report['toolchains']['baseline']==report['toolchains']['candidate']
        # A and A2 run the exact same baseline binary, with fresh fixtures.
        builds={'baseline-a':'baseline','baseline-b':'baseline','candidate':'candidate'}
        for number in range(12):
            for case,(package,pattern,duration) in cases.items():
                for position,name in enumerate(benchmark_order(builds,number)):
                    raw=run([str(binaries[builds[name],package]),'-test.run=^$',f'-test.bench={pattern}',
                             f'-test.benchtime={duration}','-test.benchmem','-test.timeout=10m'],
                            source,env,out/f'{case}-{number}-{name}.txt',timeout=300)
                    s=parse_sample(raw,number)
                    report['samples'].append(dict(s,case=case,build=name,position=position))
            (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
            print(f'A/A/B round {number+1}/12 complete',flush=True)
        if report['source_sha256']!=candidate_digest(source,out) or report['harness_inputs']!=harness_inputs(source/'scripts') or report['driver_sha256']!=hashlib.sha256(Path(__file__).read_bytes()).hexdigest():
            raise RuntimeError('Comparison inputs changed')


if __name__=='__main__':
    main()
