from pathlib import Path
import os, runpy, sys
root = Path(__file__).resolve().parent
os.chdir(root / "candidate")
sys.argv = ["benchmark_snapshot_integration.py", "--baseline", str(root / "baseline"), "--output", str(root / "results"), "--revision", "3a0cf85 private accessible merge inputs", "--scope", "merge-inputs", "--rounds", "5"]
runpy.run_path("scripts/benchmark_snapshot_integration.py", run_name="__main__")
