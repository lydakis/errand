Frozen comparison inputs. Baseline production is git commit 3a0cf85.
Create baseline and candidate directories from that commit with git archive.
Apply candidate.patch only to candidate. Copy apply_materialize_benchmark_test.go
into internal/changes in BOTH trees. Place compare.py beside those directories,
then run python3 compare.py on the native host. It runs validation and five
alternating pairs, keeping results outside the source roots.

The patch includes the benchmark driver's merge-inputs scope and candidate tests.
The benchmark-only function adapter permits identical benchmark sources across
the baseline and candidate APIs. Raw reports record the full source and binary
hashes; docs added after freezing are not inputs to the Go source digests.
