from pathlib import Path
import hashlib, json, os, platform, sys, time
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'candidate/scripts'))
from benchmark_snapshot_integration import benchmark_campaign, benchmark_order, filesystem, parse_sample, run, source_digest
os.chdir(root/'candidate')
output=root/'confirmation';output.mkdir()
roots={v:root/v for v in ('baseline','candidate')}
cases={'fetch-large':'^BenchmarkFetchBodies$/^large$', 'fetch-false':'^BenchmarkFetchCompletion$/^persistent=false$'}
env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0')
report=dict(status='running',rounds=5,platform=platform.platform(),versions={},orders=[],cases=cases,reason='Predeclared follow-up of APFS large-fetch slowdown in all five primary pairs, and four of five ephemeral-fetch pairs. Same production and benchmark sources, same three iterations; no repeated correctness suite.',harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with benchmark_campaign(output,report) as scratch:
 fixtures=scratch/'fixtures';fixtures.mkdir();env['TMPDIR']=str(fixtures)
 report['fixture_filesystem']=filesystem(fixtures,env,output,'fixture-filesystem')
 for name,source in roots.items():
  (output/name).mkdir();(scratch/name).mkdir()
  binary=scratch/name/'errand.test'
  run(['go','test','-c','-o',str(binary),'./cmd/errand'],source,env,output/name/'build.txt')
  report['versions'][name]=dict(source_sha256=source_digest(source),production_sha256=source_digest(source,production=True),benchmark_sha256=source_digest(source,benchmarks=True),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),samples=[])
 assert len({v['benchmark_sha256'] for v in report['versions'].values()})==1
 for number in range(5):
  # Start candidate first, opposite to the primary campaign.
  order=benchmark_order(roots,number+1);report['orders'].append(order)
  for case,pattern in cases.items():
   for name in order:
    report['active']=dict(round=number,case=case,variant=name)
    (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    start=time.monotonic();load=os.getloadavg()
    raw=run([str(scratch/name/'errand.test'),'-test.v','-test.run=^$',f'-test.bench={pattern}','-test.benchtime=3x','-test.benchmem'],roots[name],env,output/name/f'{number}-{case}.txt',timeout=300)
    sample=parse_sample(raw,number);sample.update(case=case,elapsed=time.monotonic()-start,load_before=load,load_after=os.getloadavg());report['versions'][name]['samples'].append(sample);report.pop('active')
    (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
   print(f'Pair {number+1}/5: {case}',flush=True)
 for name,source in roots.items():
  assert source_digest(source)==report['versions'][name]['source_sha256']
