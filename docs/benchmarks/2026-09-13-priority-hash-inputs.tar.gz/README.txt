Apply either variant over the candidate reconstructed from 2026-09-13-snapshot-review-fix-inputs.tar.gz. The priority-hash-probe JSON contains the exact driver, source hashes and raw logs.
