package manifest

import (
	"context"
	"fmt"
	"github.com/lydakis/errand/internal/proto"
	"testing"
)

func BenchmarkIndexPreparation(b *testing.B) {
	for _, count := range []int{10000, 100000} {
		b.Run(fmt.Sprint(count), func(b *testing.B) {
			entries := make([]proto.ManifestEntry, count)
			for i := range entries {
				entries[i] = proto.ManifestEntry{Path: fmt.Sprintf("file-%06d", i), Type: proto.EntryFile, Size: 1024, SHA256: fmt.Sprintf("%064x", i)}
			}
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				s, err := New(context.Background(), proto.Manifest{Entries: entries})
				if err != nil {
					b.Fatal(err)
				}
				if err = s.PrepareUpdates(context.Background()); err != nil {
					b.Fatal(err)
				}
				if _, err = s.RootHash(context.Background()); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}
