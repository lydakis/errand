"""Resume retained native comparisons without splitting a paired leaf."""
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import time

from benchmark_snapshot_integration import filesystem, benchmark_order

root = Path.cwd()
seed = root.parent / 'seed-results'
output = root.parent / 'results'
shutil.copytree(seed, output, ignore=shutil.ignore_patterns('fixtures'))
original = (seed / 'report.json').read_bytes()
(output / 'interrupted-report.json').write_bytes(original)
report = json.loads(original)
roots = {name: root.parent / name for name in report['versions']}
env = dict(os.environ, GOMAXPROCS=str(report['gomaxprocs']), CGO_ENABLED='0')
deadline = time.monotonic() + 90 * 60
assert platform.machine() == report['machine']
assert subprocess.check_output(['go', 'version'], env=env, text=True).strip() == report['go']
assert hashlib.sha256((root / 'scripts/benchmark_snapshot_integration.py').read_bytes()).hexdigest() == report['harness_sha256']
for name, directory in roots.items():
    digest = hashlib.sha256()
    for path in sorted([*directory.rglob('*.go'), directory / 'go.mod', directory / 'go.sum']):
        digest.update(str(path.relative_to(directory)).encode() + b'\0' + path.read_bytes() + b'\0')
    assert digest.hexdigest() == report['versions'][name]['source_sha256'], name
    for key, expected in report['versions'][name]['binaries'].items():
        binary = output / name / (key + '.test')
        assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected, (name, key)
        binary.chmod(binary.stat().st_mode | 0o100)
fixtures = output / 'fixtures'
fixtures.mkdir()
env['TMPDIR'] = str(fixtures)
actual_fs = filesystem(fixtures, env, output, 'resume-fixture-filesystem')
assert actual_fs == report['fixture_filesystem'], actual_fs
resume = dict(reason='Intentional continuation after five complete rounds to avoid the two-hour runner cap', prior_job='mac-mini/01M2EEB6HEBFA0MZ27WCWCEQKX',
              prior_report_sha256=hashlib.sha256(original).hexdigest(),
              helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              fixture_root=str(fixtures), fixture_filesystem=actual_fs,
              budget_seconds=90 * 60, interrupted_leaves=[], completed_leaves=[])
report.setdefault('resumptions', []).append(resume)

def save():
    pending = output / 'report.json.tmp'
    pending.write_text(json.dumps(report, indent=2) + '\n')
    pending.replace(output / 'report.json')

save()
for number in range(report['rounds']):
    if number >= len(report['orders']):
        report['orders'].append(benchmark_order(roots, number))
    for key, (package, pattern, benchtime) in report['cases'].items():
        expected_name = pattern.replace('^', '').replace('$', '')
        assert re.fullmatch(r'[A-Za-z0-9_=/.-]+', expected_name)
        matching = lambda row: row['round'] == number and row['name'] == expected_name
        present = {name: sum(matching(row) for row in report['versions'][name]['samples']) for name in roots}
        assert all(count in (0, 1) for count in present.values())
        if all(present.values()):
            continue
        if any(present.values()):
            resume['interrupted_leaves'].append(dict(round=number, case=key, partial_counts=present))
            for name in roots:
                data = report['versions'][name]
                data['samples'] = [row for row in data['samples'] if not matching(row)]
                prior_log = output / name / f'{number}-{key}.txt'
                if prior_log.exists():
                    prior_log.rename(prior_log.with_name('interrupted-' + prior_log.name))
            save()
        for name in report['orders'][number]:
            binary_key = package.removeprefix('./').replace('/', '-')
            command = [str(output / name / (binary_key + '.test')), '-test.v', '-test.run=^$',
                       f'-test.bench={pattern}', f'-test.benchtime={benchtime}', '-test.benchmem', '-test.timeout=10m']
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise RuntimeError('90-minute continuation budget exhausted; report is resumable')
            result = subprocess.run(command, cwd=roots[name], env=env, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=remaining)
            (output / name / f'{number}-{key}.txt').write_text(result.stdout)
            if result.returncode:
                raise RuntimeError((key, name, result.returncode))
            samples = []
            for line in result.stdout.splitlines():
                match = re.match(r'^(Benchmark\S+)-\d+\s+(\d+)\s+(.+)$', line)
                if not match:
                    continue
                metrics = match[3].split()
                assert len(metrics) % 2 == 0
                samples.append(dict(name=match[1], iterations=int(match[2]), round=number,
                                    metrics={metrics[i+1]: float(metrics[i]) for i in range(0, len(metrics), 2)}))
            assert len(samples) == 1 and samples[0]['name'] == expected_name, (key, samples)
            report['versions'][name]['samples'].extend(samples)
            save()
        resume['completed_leaves'].append(dict(round=number, case=key))
        save()
        print(f'Resumed pair {number+1}/{report["rounds"]}: {key}', flush=True)
for name in roots:
    assert len(report['versions'][name]['samples']) == report['rounds'] * len(report['cases'])
    for key in report['versions'][name]['binaries']:
        (output / name / (key + '.test')).unlink()
print('All seven native comparison rounds complete', flush=True)
