package changes

import (
	"encoding/json"
	"errors"
	"fmt"
	"golang.org/x/sys/unix"
	"os"
	"path/filepath"
	"reflect"
	"testing"
)

func TestExchangeCrashRecovery(t *testing.T) {
	for _, paths := range [][]string{{"a", "b", "c"}, {"x/a", "y/b", "y/c"}} {
		for _, tc := range []struct {
			event string
			index int
		}{
			{"staged", -1}, {"exchange-intent", -1}, {"exchange-ready", 0}, {"exchange-rename", 0}, {"exchange-rename", 1},
			{"exchange-backup", 1}, {"exchange-member", 1}, {"exchange-barrier", -1}, {"exchange-installed", -1}, {"committed", -1},
		} {
			t.Run(fmt.Sprintf("%s/%s-%d", paths[0], tc.event, tc.index), func(t *testing.T) {
				target, bundle, staged := groupFixturePaths(t, paths)
				crashGroupedApply(t, target, bundle, staged, tc.event, tc.index)
				if tc.event != "committed" {
					var state transferApplyState
					raw, err := os.ReadFile(target.StatePath)
					if err != nil {
						t.Fatal(err)
					}
					if err := json.Unmarshal(raw, &state); err != nil {
						t.Fatal(err)
					}
					d, err := openApplyDestination(target.Root)
					if err != nil {
						t.Fatal(err)
					}
					defer d.Close()
					if err := target.recoverTransfer(d, &state, func() error { persistTransferState(t, target, state); return nil }); err != nil {
						t.Fatal(err)
					}
					for _, name := range paths {
						assertTransferFile(t, target.Root, name, "before-"+name)
					}
				}
				result, err := target.Apply(staged, bundle, nil, ApplyOptions{})
				if err != nil {
					t.Fatal(err)
				}
				for _, name := range paths {
					assertTransferFile(t, target.Root, name, "after-"+name)
				}
				writeTransferFile(t, target.Root, paths[0], "later")
				retry, err := target.Apply(staged, bundle, nil, ApplyOptions{})
				if err != nil || !reflect.DeepEqual(result, retry) {
					t.Fatalf("retry: %v", err)
				}
				assertTransferFile(t, target.Root, paths[0], "later")
			})
		}
	}
}

func TestExchangeUnsupportedUsesReference(t *testing.T) {
	target, bundle, staged := groupFixture(t)
	reference := false
	_, err := target.Apply(staged, bundle, nil, ApplyOptions{
		exchangeRename: func(*os.File, string, *os.File, string) error { return unix.ENOTSUP },
		groupCheckpoint: func(event string, i int) error {
			if event == "intent" {
				reference = true
			}
			return nil
		},
	})
	if err != nil || !reference {
		t.Fatalf("fallback: %v %v", reference, err)
	}
	for _, p := range bundle.Paths {
		assertTransferFile(t, target.Root, p, "after-"+p)
	}
}

func TestExchangePreservesConcurrentEdits(t *testing.T) {
	for _, when := range []string{"before", "installed", "swap-window"} {
		t.Run(when, func(t *testing.T) {
			target, bundle, staged := groupFixture(t)
			injected := errors.New("stop")
			_, err := target.Apply(staged, bundle, nil, ApplyOptions{groupCheckpoint: func(event string, i int) error {
				if when == "before" && event == "exchange-before" && i == 1 {
					writeTransferFile(t, target.Root, "b", "later")
					return injected
				}
				if when == "installed" && event == "exchange-rename" && i == 0 {
					writeTransferFile(t, target.Root, "a", "later")
					return injected
				}
				if when == "swap-window" && event == "exchange-ready" && i == 0 {
					replacement := filepath.Join(target.Root, "replacement")
					if err := os.WriteFile(replacement, []byte("later"), 0600); err != nil {
						t.Fatal(err)
					}
					if err := os.Rename(replacement, filepath.Join(target.Root, "a")); err != nil {
						t.Fatal(err)
					}
				}
				return nil
			}})
			if err == nil {
				t.Fatal("expected conflict")
			}
			name := "a"
			if when == "before" {
				name = "b"
			}
			assertTransferFile(t, target.Root, name, "later")
			if when == "installed" {
				if pending, e := WorkspaceHasApplyTransactions(target.Root); e != nil || !pending {
					t.Fatal("lost backup", e)
				}
			}
		})
	}
}
