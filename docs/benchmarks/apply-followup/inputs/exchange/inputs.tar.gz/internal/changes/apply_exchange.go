package changes

// EXPERIMENT ONLY. This file is introduced by experiments/applyexchange/candidate.patch.
import (
	"context"
	"errors"
	"fmt"
	"os"
	"path"
	"sort"

	"github.com/lydakis/errand/internal/fsidentity"
	"golang.org/x/sys/unix"
)

const applyItemExchanging = "group-exchanging"

type exchangeRenameFunc func(*os.File, string, *os.File, string) error

func (g *applyFileGroup) exchangeSupported(root *os.Root, journal applyJournal) (bool, error) {
	dir, err := root.Open(journal.Transaction)
	if err != nil {
		return false, err
	}
	defer dir.Close()
	for _, name := range []string{"probe-a", "probe-b"} {
		p := path.Join(journal.Transaction, name)
		file, err := root.OpenFile(p, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err != nil {
			return false, err
		}
		defer root.Remove(p)
		if err := file.Close(); err != nil {
			return false, err
		}
	}
	err = g.swap(dir, "probe-a", dir, "probe-b")
	if errors.Is(err, unix.ENOTSUP) || errors.Is(err, unix.ENOSYS) || errors.Is(err, unix.EINVAL) {
		return false, nil
	}
	return err == nil, err
}

func exchangeIdentity(root *os.Root, p string) (fsidentity.Identity, error) {
	info, err := root.Lstat(p)
	if err != nil {
		return fsidentity.Identity{}, err
	}
	if !info.Mode().IsRegular() {
		return fsidentity.Identity{}, fmt.Errorf("exchange requires regular file %q", p)
	}
	return fsidentity.FromInfo(info)
}

func (g *applyFileGroup) installExchange(destination *applyDestination, journal *applyJournal, synchronization applySynchronization) error {
	root := destination.root
	// The staged inode and original inode distinguish the two sides of a swap.
	// Both names exist in BOTH states; path existence alone cannot do this.
	for i := range journal.Items {
		item := &journal.Items[i]
		var err error
		item.ExchangeValue, err = exchangeIdentity(root, path.Join(journal.Transaction, item.ItemDir, "value"))
		if err != nil {
			return err
		}
		item.ExchangeOriginal, err = exchangeIdentity(root, item.Path)
		if err != nil {
			return err
		}
		item.Parent, item.Phase = g.parents[path.Dir(item.Path)], applyItemExchanging
	}
	if err := writeApplyJournalAtRoot(root, *journal); err != nil {
		return err
	}
	if err := g.check("exchange-intent", -1); err != nil {
		return err
	}
	for i, item := range journal.Items {
		if err := g.exchangeItem(destination, *journal, item, i, synchronization); err != nil {
			return err
		}
	}
	if err := g.check("exchange-barrier", -1); err != nil {
		return err
	}
	names := make([]string, 0, len(g.parents))
	for name := range g.parents {
		names = append(names, name)
	}
	sort.Strings(names)
	for _, name := range names {
		parent, err := openChangeParent(root, path.Join(name, "unused"), g.parents[name])
		if err != nil {
			return err
		}
		err = synchronization.barrier("exchange-parent", parent)
		if err := errors.Join(err, parent.Close()); err != nil {
			return err
		}
	}
	if err := destination.verifyPath(); err != nil {
		return err
	}
	if err := g.check("exchange-installed", -1); err != nil {
		return err
	}
	for i := range journal.Items {
		journal.Items[i].Phase = applyItemInstalled
	}
	return nil
}

func (g *applyFileGroup) exchangeItem(destination *applyDestination, journal applyJournal, item applyJournalItem, i int, synchronization applySynchronization) error {
	root := destination.root
	parent, err := openChangeParent(root, item.Path, item.Parent)
	if err != nil {
		return err
	}
	defer parent.Close()
	dir, err := root.Open(path.Join(journal.Transaction, item.ItemDir))
	if err != nil {
		return err
	}
	defer dir.Close()
	if err := g.check("exchange-before", i); err != nil {
		return err
	}
	if err := errors.Join(destination.verifyPath(), verifyChangeParent(root, item.Path, item.Parent)); err != nil {
		return err
	}
	got, _, _, err := captureApplyItemBaseline(context.Background(), root, item)
	if err != nil {
		return err
	}
	if !sameBaseline(got, item.Original) {
		return fmt.Errorf("exchange %q conflicts with local changes", item.Path)
	}
	// Preserve dirty original data as well as namespace entries. Atomic visibility
	// alone establishes neither data persistence nor conflict freedom.
	original, err := openSearchSourceFile(root, item.Path)
	if err != nil {
		return err
	}
	if err := errors.Join(synchronization.member("exchange-original", original), original.Close()); err != nil {
		return err
	}
	if err := g.check("exchange-ready", i); err != nil {
		return err
	}
	if err := g.swap(parent, path.Base(item.Path), dir, "value"); err != nil {
		return err
	}
	if err := g.check("exchange-rename", i); err != nil {
		return err
	}
	// Normalize displaced content to the existing backup name. A crash before
	// this rename is recovered using the inode evidence above.
	if err := renameNoReplace(dir, "value", dir, "previous"); err != nil {
		return err
	}
	if err := g.check("exchange-backup", i); err != nil {
		return err
	}
	if err := synchronizeApplyBackup(root, journal, item, synchronization); err != nil {
		return err
	}
	if err := synchronization.member("exchange-directory", dir); err != nil {
		return err
	}
	return g.check("exchange-member", i)
}

// Normalize an interrupted exchange into the existing quarantine/no-replace
// rollback protocol. Never exchange backwards: that would overwrite a concurrent
// edit appearing after the destination check.
func prepareExchangeRollback(ctx context.Context, root *os.Root, journal applyJournal, item applyJournalItem) (bool, error) {
	value := path.Join(journal.Transaction, item.ItemDir, "value")
	staged, err := exchangeIdentity(root, value)
	if os.IsNotExist(err) {
		return false, nil
	} // normalized backup or completed rollback
	if err != nil {
		return false, err
	}
	if staged == item.ExchangeValue {
		got, err := captureBaselineAtRootContext(ctx, root, value, item.Path)
		if err != nil {
			return false, err
		}
		if !sameBaselineContent(got, item.Expected) {
			return false, fmt.Errorf("exchange staged value changed; retained")
		}
		return true, nil // swap did not occur; preserve any later edit/deletion
	}
	live, liveErr := exchangeIdentity(root, item.Path)
	if staged != item.ExchangeOriginal && (liveErr != nil || live != item.ExchangeValue) {
		return false, fmt.Errorf("ambiguous exchange evidence for %q; retained", item.Path)
	}
	dir, err := root.Open(path.Dir(value))
	if err != nil {
		return false, err
	}
	defer dir.Close()
	if err := renameNoReplace(dir, "value", dir, "previous"); err != nil {
		return false, err
	}
	// Recovery is deliberately conservative and uses the durable reference barrier.
	backup, err := openSearchSourceFile(root, path.Join(path.Dir(value), "previous"))
	if err != nil {
		return false, err
	}
	if err := errors.Join(backup.Sync(), backup.Close()); err != nil {
		return false, err
	}
	return false, dir.Sync()
}
