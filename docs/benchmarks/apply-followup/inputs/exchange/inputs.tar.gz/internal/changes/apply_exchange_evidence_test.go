package changes

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestExchangeRejectsAmbiguousEvidence(t *testing.T) {
	target, bundle, staged := groupFixture(t)
	crashGroupedApply(t, target, bundle, staged, "exchange-intent", -1)
	var state transferApplyState
	raw, err := os.ReadFile(target.StatePath)
	if err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(raw, &state); err != nil {
		t.Fatal(err)
	}
	value := filepath.Join(target.Root, state.Pending, "000000", "value")
	// Replace the staged inode, while retaining its bytes. Content equality alone
	// cannot authorize treating it as either an untouched value or a backup.
	body, err := os.ReadFile(value)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.Rename(value, value+".saved"); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(value, body, 0600); err != nil {
		t.Fatal(err)
	}
	_, err = target.Apply(staged, bundle, nil, ApplyOptions{})
	if err == nil {
		t.Fatal("accepted ambiguous inode evidence")
	}
	for _, p := range bundle.Paths {
		assertTransferFile(t, target.Root, p, "before-"+p)
	}
	if pending, e := WorkspaceHasApplyTransactions(target.Root); e != nil || !pending {
		t.Fatal("lost evidence", e)
	}
}
