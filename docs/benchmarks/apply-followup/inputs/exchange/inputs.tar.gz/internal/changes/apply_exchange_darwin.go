package changes

import (
	"golang.org/x/sys/unix"
	"os"
)

func exchangeRename(a *os.File, an string, b *os.File, bn string) error {
	return unix.RenameatxNp(int(a.Fd()), an, int(b.Fd()), bn, unix.RENAME_SWAP)
}
