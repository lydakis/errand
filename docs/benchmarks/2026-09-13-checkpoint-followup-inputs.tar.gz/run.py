from pathlib import Path
import os, sys, subprocess, time, json, hashlib, platform, re, plistlib
root=Path(__file__).resolve().parent
out=root/'results'; out.mkdir(exist_ok=False)
fixtures=out/'fixtures'; fixtures.mkdir()
env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0',TMPDIR=str(fixtures))
report=dict(baseline='de25693',host=platform.platform(),machine=platform.machine(),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),gomaxprocs=2,variants={},samples=[],warmups=[],validation={},orders=[])
def save(): (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(cmd,cwd,log,extra=None):
 t=time.monotonic()
 p=subprocess.run(cmd,cwd=cwd,env=env if extra is None else dict(env,**extra),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/log).write_text(p.stdout)
 if p.returncode: raise RuntimeError(f'{cmd}: exit {p.returncode}; {log}')
 return p.stdout,time.monotonic()-t
report['go']=run(['go','version'],root,'go.txt')[0].strip()
if sys.platform=='darwin':
 disk=run(['df','-P','.'],fixtures,'df.txt')[0].splitlines()[-1].split()[0]
 report['filesystem']=plistlib.loads(run(['diskutil','info','-plist',disk],fixtures,'filesystem.txt')[0].encode())['FilesystemType']
else: report['filesystem']=run(['stat','-f','-c','%T','.'],fixtures,'filesystem.txt')[0].strip()
variants=['baseline','local','shared']
for name in variants:
 tree=root/name; (out/name).mkdir()
 h=hashlib.sha256()
 for p in sorted([*tree.rglob('*.go'),tree/'go.mod',tree/'go.sum']): h.update(str(p.relative_to(tree)).encode()+b'\0'+p.read_bytes()+b'\0')
 report['variants'][name]=dict(source_sha256=h.hexdigest(),binaries={})
 if name=='shared':
  for label,cmd,extra in [
   ('tests',['go','test','-timeout=10m','./...'],None),
   ('vet',['go','vet','./...'],None),
   ('race',['go','test','-race','-timeout=10m','./internal/changes','./internal/daemon','./internal/client','./cmd/errand'],{'CGO_ENABLED':'1'}),
  ]:
   _,elapsed=run(cmd,tree,f'{name}/{label}.txt',extra); report['validation'][label]=elapsed; save(); print(f'{name}: {label} passed',flush=True)
 elif name=='local':
  run(['go','test','-timeout=10m','./internal/changes','./internal/daemon'],tree,f'{name}/tests.txt'); print('local: affected tests passed',flush=True)
 for package in ('internal/changes','cmd/errand'):
  binary=out/name/(package.replace('/','-')+'.test')
  run(['go','test','-c','-o',str(binary),'./'+package],tree,f'{name}/build-{package.replace("/","-")}.txt')
  report['variants'][name]['binaries'][package]=hashlib.sha256(binary.read_bytes()).hexdigest()
 save()
def bench(name,key,pattern,duration,number,package='internal/changes',warmup=False):
 log=f'{name}/{number}-{key}.txt'; load=os.getloadavg()
 raw,elapsed=run([str(out/name/(package.replace('/','-')+'.test')),'-test.run=^$',f'-test.bench={pattern}',f'-test.benchtime={duration}','-test.benchmem','-test.timeout=10m'],root/name,log)
 matches=[]
 for line in raw.splitlines():
  m=re.match(r'^(Benchmark\S+)-\d+\s+(\d+)\s+(.+)$',line)
  if m:
   metrics=m[3].split(); matches.append(dict(name=m[1],iterations=int(m[2]),metrics={metrics[i+1]:float(metrics[i]) for i in range(0,len(metrics),2)}))
 if len(matches)!=1: raise RuntimeError(f'expected one sample in {log}: {matches}')
 sample=dict(variant=name,case=key,round=number,load_before=load,load_after=os.getloadavg(),elapsed=elapsed,log=log,**matches[0])
 report['warmups' if warmup else 'samples'].append(sample); save()
def order(n):
 names=variants[n%3:]+variants[:n%3]
 return names if n%2==0 else list(reversed(names))
for n in range(7):
 names=order(n);report['orders'].append(names)
 for count in (1000,10000):
  for phase in ('cold-read','initialize-existing'):
   for name in names: bench(name,f'{count}-{phase}',f'^BenchmarkCheckpointLifecycle$/^{count}$/^{phase}$','300ms',n)
 # Rotate the two cache modes; independent fresh handles in both.
 for reuse in ([False,True] if n%2==0 else [True,False]):
  bench('shared',f'cache-{reuse}',f'^BenchmarkCheckpointRequests$/^reuse={str(reuse).lower()}$','300ms',n)
 print(f'lifecycle round {n+1}/7 complete',flush=True)
for name in variants: bench(name,'watch-warmup','^BenchmarkWatchPhases$','1x',-1,'cmd/errand',True)
for n in range(7):
 for name in order(n): bench(name,'watch','^BenchmarkWatchPhases$','5x',n,'cmd/errand')
 print(f'watch round {n+1}/7 complete',flush=True)
controls={
 'push':'^BenchmarkPushPhases$',
 'persistent-fetch':'^BenchmarkFetchCompletion$/^persistent=true$',
 'ephemeral-fetch':'^BenchmarkFetchCompletion$/^persistent=false$',
 'workspace-create':'^BenchmarkWorkspaceCreationAndSubmission$/^workspace-create$',
 'ephemeral-job':'^BenchmarkWorkspaceCreationAndSubmission$/^ephemeral-job$',
}
for n in range(3):
 for key,pattern in controls.items():
  for name in (['baseline','shared'] if n%2==0 else ['shared','baseline']): bench(name,key,pattern,'3x',n,'cmd/errand')
  print(f'control round {n+1}/3: {key}',flush=True)
for p in out.rglob('*.test'): p.unlink()
print('COMPLETE',flush=True)
