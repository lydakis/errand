from pathlib import Path
import os,subprocess,time,json,hashlib,platform,re,plistlib
root=Path(__file__).resolve().parent;out=root/'confirmation';out.mkdir();fixtures=out/'fixtures';fixtures.mkdir()
env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0',TMPDIR=str(fixtures))
original=json.loads((root/'results/report.json').read_text())
r=dict(reason='Independent follow-up of adverse three-pair control estimates, including identical baseline binaries in two labeled positions. No original samples are discarded or pooled into this run.',host=platform.platform(),machine=platform.machine(),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),variants={},samples=[],orders=[])
def run(cmd,cwd,log):
 t=time.monotonic();p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/log).write_text(p.stdout)
 if p.returncode:raise RuntimeError(f'{log}: exit {p.returncode}')
 return p.stdout,time.monotonic()-t
assert r['host']==original['host'] and r['machine']==original['machine']
r['go']=run(['go','version'],root,'go.txt')[0].strip();assert r['go']==original['go']
r['filesystem']=run(['stat','-f','-c','%T','.'],fixtures,'filesystem.txt')[0].strip();assert r['filesystem']==original['filesystem']
run(['ps','-eo','comm,pcpu,stat'],root,'process-load-before.txt')
for name in ('baseline','shared'):
 h=hashlib.sha256();tree=root/name
 for p in sorted([*tree.rglob('*.go'),tree/'go.mod',tree/'go.sum']):h.update(str(p.relative_to(tree)).encode()+b'\0'+p.read_bytes()+b'\0')
 assert h.hexdigest()==original['variants'][name]['source_sha256']
 binary=root/'results'/name/'cmd-errand.test';digest=hashlib.sha256(binary.read_bytes()).hexdigest();assert digest==original['variants'][name]['binaries']['cmd/errand']
 r['variants'][name]=dict(source_sha256=h.hexdigest(),binary_sha256=digest)
r['variants']['shadow']=dict(r['variants']['baseline'],same_binary_as='baseline')
for name in r['variants']:(out/name).mkdir()
def parse(raw):
 matches=[];pending=None
 for line in raw.splitlines():
  head=re.match(r'^(Benchmark\S+)-\d+\s*(.*)$',line)
  if head:pending=head[1];line=head[2]
  m=re.match(r'^\s*(\d+)\s+(.+)$',line)
  if pending and m:
   f=m[2].split()
   if len(f)%2 or 'ns/op' not in f:continue
   matches.append(dict(name=pending,iterations=int(m[1]),metrics={f[i+1]:float(f[i]) for i in range(0,len(f),2)}));pending=None
 assert len(matches)==1
 return matches[0]
variants=['baseline','shadow','shared'];cases={'ephemeral-fetch':'^BenchmarkFetchCompletion$/^persistent=false$','workspace-create':'^BenchmarkWorkspaceCreationAndSubmission$/^workspace-create$','ephemeral-job':'^BenchmarkWorkspaceCreationAndSubmission$/^ephemeral-job$'}
for n in range(7):
 order=variants[n%3:]+variants[:n%3]
 if n%2:order.reverse()
 r['orders'].append(order)
 for case,pattern in cases.items():
  for name in order:
   actual='baseline' if name=='shadow' else name;load=os.getloadavg();log=f'{name}/{n}-{case}.txt'
   raw,elapsed=run([str(root/'results'/actual/'cmd-errand.test'),'-test.run=^$',f'-test.bench={pattern}','-test.benchtime=3x','-test.benchmem','-test.timeout=10m'],root/actual,log)
   r['samples'].append(dict(variant=name,case=case,round=n,log=log,elapsed=elapsed,load_before=load,load_after=os.getloadavg(),**parse(raw)))
   (out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 print(f'confirmation round {n+1}/7 complete',flush=True)
run(['ps','-eo','comm,pcpu,stat'],root,'process-load-after.txt')
assert len(r['samples'])==63
print('COMPLETE',flush=True)
