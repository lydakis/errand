from pathlib import Path
import os,sys,subprocess,time,json,hashlib,platform,re,plistlib
root=Path(__file__).resolve().parent;out=root/'results'
report=json.loads((out/'report.json').read_text()); original=json.loads(json.dumps(report))
fixtures=out/'resume-fixtures';fixtures.mkdir(exist_ok=False)
env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0',TMPDIR=str(fixtures))
def run(cmd,cwd,log):
 t=time.monotonic();p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/log).write_text(p.stdout)
 if p.returncode:raise RuntimeError(f'{cmd}: exit {p.returncode}; {log}')
 return p.stdout,time.monotonic()-t
assert platform.platform()==report['host'] and platform.machine()==report['machine']
assert run(['go','version'],root,'resume-go.txt')[0].strip()==report['go']
if sys.platform=='darwin':
 disk=run(['df','-P','.'],fixtures,'resume-df.txt')[0].splitlines()[-1].split()[0]
 fs=plistlib.loads(run(['diskutil','info','-plist',disk],fixtures,'resume-filesystem.txt')[0].encode())['FilesystemType']
else:fs=run(['stat','-f','-c','%T','.'],fixtures,'resume-filesystem.txt')[0].strip()
assert fs==report['filesystem']
for name,version in report['variants'].items():
 tree=root/name;h=hashlib.sha256()
 for p in sorted([*tree.rglob('*.go'),tree/'go.mod',tree/'go.sum']):h.update(str(p.relative_to(tree)).encode()+b'\0'+p.read_bytes()+b'\0')
 assert h.hexdigest()==version['source_sha256'],name
 for package,want in version['binaries'].items():assert hashlib.sha256((out/name/(package.replace('/','-')+'.test')).read_bytes()).hexdigest()==want
# Go can interleave EVALUATION rows between the name and numeric summary.
def parse(raw):
 matches=[];pending=None
 for line in raw.splitlines():
  head=re.match(r'^(Benchmark\S+)-\d+\s*(.*)$',line)
  if head:pending=head[1];line=head[2]
  m=re.match(r'^\s*(\d+)\s+(.+)$',line)
  if pending and m:
   fields=m[2].split()
   if len(fields)%2 or 'ns/op' not in fields:continue
   metrics={fields[i+1]:float(fields[i]) for i in range(0,len(fields),2)}
   matches.append(dict(name=pending,iterations=int(m[1]),metrics=metrics));pending=None
 if len(matches)!=1:raise RuntimeError(f'expected one benchmark summary: {matches}')
 return matches[0]
assert parse((out/'baseline/0-persistent-fetch.txt').read_text())['iterations']==3
assert parse((out/'baseline/0-watch.txt').read_text())['iterations']==5
report['continuation']=dict(reason='Go EVALUATION output interleaved with the fetch benchmark name; collector failed after a successful command. Preserve completed observations; repeat the unfinished fetch pair in full.',harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),previous_report_sha256=hashlib.sha256((out/'report.json').read_bytes()).hexdigest(),unpaired_log='baseline/0-persistent-fetch.txt',fixture_filesystem=fs)
(out/'initial-report.json').write_text(json.dumps(original,indent=2)+'\n')
controls={'push':'^BenchmarkPushPhases$','persistent-fetch':'^BenchmarkFetchCompletion$/^persistent=true$','ephemeral-fetch':'^BenchmarkFetchCompletion$/^persistent=false$','workspace-create':'^BenchmarkWorkspaceCreationAndSubmission$/^workspace-create$','ephemeral-job':'^BenchmarkWorkspaceCreationAndSubmission$/^ephemeral-job$'}
for n in range(3):
 for key,pattern in controls.items():
  done={s['variant'] for s in report['samples'] if s['case']==key and s['round']==n}
  if done=={'baseline','shared'}:continue
  assert not done,(key,n,done)
  for name in (['baseline','shared'] if n%2==0 else ['shared','baseline']):
   load=os.getloadavg();log=f'{name}/resume-{n}-{key}.txt'
   raw,elapsed=run([str(out/name/'cmd-errand.test'),'-test.run=^$',f'-test.bench={pattern}','-test.benchtime=3x','-test.benchmem','-test.timeout=10m'],root/name,log)
   report['samples'].append(dict(variant=name,case=key,round=n,load_before=load,load_after=os.getloadavg(),elapsed=elapsed,log=log,**parse(raw)))
   (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
  print(f'control round {n+1}/3: {key}',flush=True)
assert report['samples'][:len(original['samples'])]==original['samples']
assert len(report['samples'])==149
for p in out.rglob('*.test'):p.unlink()
print('COMPLETE',flush=True)
