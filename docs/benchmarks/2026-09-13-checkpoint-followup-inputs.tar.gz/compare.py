import json,sys,statistics
from pathlib import Path
r=json.loads(Path(sys.argv[1]).read_text())
samples=r['samples']
cases=list(dict.fromkeys(s['case'] for s in samples))
summary={}
for case in cases:
 by={v:{s['round']:s for s in samples if s['case']==case and s['variant']==v} for v in r['variants']}
 by={v:a for v,a in by.items() if a}
 metrics=['ns/op']
 if case=='watch':metrics+=['stage-ms/op','apply-ms/op','client-ms/op','negotiate-ms/op']
 row={}
 for metric in metrics:
  row[metric]={'medians':{v:statistics.median(s['metrics'][metric] for s in a.values()) for v,a in by.items()},'comparisons':{}}
  for base,candidate in [('baseline','local'),('baseline','shared'),('local','shared')]:
   if base not in by or candidate not in by:continue
   pairs=sorted(set(by[base])&set(by[candidate]))
   ratios=[by[candidate][i]['metrics'][metric]/by[base][i]['metrics'][metric] for i in pairs if by[base][i]['metrics'][metric]>0]
   if not ratios:continue
   row[metric]['comparisons'][candidate+'/'+base]=dict(pairs=len(ratios),median_ratio=statistics.median(ratios),range=[min(ratios),max(ratios)],faster=sum(v<1 for v in ratios),ratios=ratios)
 summary[case]=row
summary['provenance']={k:r[k] for k in ('host','filesystem','go','baseline','harness_sha256','validation')}
print(json.dumps(summary,indent=2))
