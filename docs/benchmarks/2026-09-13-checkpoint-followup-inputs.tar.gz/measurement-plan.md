# Receiver checkpoint follow-up

Baseline: `de25693` (`Reuse validated transfer checkpoint reads`).

## Candidates

1. Remove the second guarded read and unused public manifest export during
   existing-session initialization. Keep creation-manifest validation, relationship
   checks, and first-initialization blob durability. Replace apply's refused-merge
   dry run with the same selected merge-base check, without revalidating the
   unchanged, previously validated checkpoint.
2. Keep decoded metadata and lazy identity in a private immutable record. Session
   callers request revision, delta, and merge-base operations instead of borrowing
   manifest slices. Public exports still copy. Memoized identity uses `sync.Once`
   so independent read-only request handles can share a record safely.
3. Compare that request-local candidate with a receiver-owned LRU shared across
   daemon requests. Every request still performs guarded, bounded record I/O,
   exact-byte comparison, and relationship checks. The workspace store retains
   at most 32 records and 64 MiB of accounted backing buffers, entry arrays and
   strings. Active operations may retain evicted records; this is not a total
   process-memory limit. Workspace removal releases matching entries. Transfer
   GC leaves the pinned checkpoint intact. Publication invalidates cached records
   before writing; successful writes are not speculatively seeded into the cache.

The implementation belongs to the shared `changes` receiver code. Push/watch
use the longer-lived daemon owner. Persistent fetch uses the same record and
validation improvements; separate CLI processes cannot share an in-memory cache.
Fresh workspace/job creation and ephemeral fetch remain regression controls.
Merkle selection, wire identity, fsync batching and publication barriers stay fixed.

## Measurement plan (declared before native timings)

Freeze three trees: committed baseline plus identical lifecycle benchmark,
request-local candidate, and shared-cache candidate. The local and shared
candidates differ only in enabling retention in `openWorkspaces`.

Use native APFS and Btrfs fixtures with GOMAXPROCS=2. Validate the shared candidate
with the full Go suite, vet, and scoped race tests (including daemon); validate
the local candidate's affected packages. Compile all three variants on each host.
Record source, harness and binary hashes, Go version, fixture filesystem and load.

Seven rotating/reversing rounds compare 1K/10K cold reads and existing-session
initialization across all three variants. Also record enabled/disabled cache
reads through independent request handles. Complete watch uses seven rounds of
five edits per variant. One untimed watch run per variant warms executable and
filesystem paths before those observations; retain its raw log separately.

Three alternating pairs of ordinary push, persistent and ephemeral fetch, fresh
workspace creation, and job submission screen for regressions against baseline.
These controls do not establish equivalence. Keep every measured observation;
record host load without post-hoc outlier removal. No new rsync/Mutagen or
cross-host network claim follows from these native loopback measurements.

Report medians and paired candidate/baseline ratios. Seven-pair ranges provide
per-comparison sign-test bounds under independent pairs, not simultaneous
confidence across workloads. Treat component improvements separately from
complete-command latency. A shared-cache speed claim needs a complete-watch
improvement over the request-local candidate; a warm-read microbenchmark alone
is insufficient. An inconclusive experiment stays labeled inconclusive.
