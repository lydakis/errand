# errand — a personal job runner for machines you own

> This document describes the current implementation on `main`, including
> unreleased work. See the [roadmap](#roadmap) for completed capabilities,
> the next release, and deferred work.

Run the thing you would have run locally, on another machine you own, and
get the result back. Same argv, same working tree, logs streaming to your
terminal, real exit code — the heat, watts, and minutes spent elsewhere.

Not part of Atlas. If the two ever meet, errand is a client that targets an
Atlas Surface — never the other way around.

## The conceptual center: a remote process transaction

errand's unit of value is not a connection, it is a transaction:

> Capture a workspace snapshot, authorize the caller, execute once —
> without replay on retry — stream an ordered result, retain workspace
> changes safely, clean up what errand owns, and leave an append-only receipt.

Everything below serves that. Without those properties errand is ssh plus
tar; with them it is a tool.

This is also the answer to "why not just ssh?" — ssh gives you a remote
shell and assumes the remote already has your project state: a checkout on
the right branch, your uncommitted changes, no stale artifacts. Every ssh
target is a pet you maintain. Errand ships the workspace with the job, so
targets are **stateless with respect to your projects**: nothing checked
out, nothing drifting, any peer equally valid at any moment. The snapshot
round-trip is what makes errand more than a shell; the transaction
properties are what make the round-trip trustworthy.

### The v0 fidelity contract

"As if you ran it locally" means exactly this in v0, no more:

- Transported faithfully: argv, the workspace snapshot, explicitly declared
  environment values, relative working directory, stdout/stderr in
  daemon-observed order, selected signals, exit status, and explicitly
  attached local TCP forwards.
- Not reproduced: ambient local environment, an interactive terminal
  (no stdin, no PTY — non-interactive only), ambient local network access, or
  the local platform. Results are native to the *target*; a binary built on
  x86 Linux is an x86 Linux binary, and the receipt says so.
- Command means **argv**, executed directly. Shell composition is explicit:
  `errand -- sh -lc 'cargo test && cargo clippy'`.

## Beliefs

- Transport is not authorization. Every request is authorized against an
  explicit, revocable grant, even between your own devices.
- **An errand execution grant is shell access as the job's OS user on that
  machine. Grant it as carefully as SSH access.** Arbitrary commands can
  read and exfiltrate anything that user can read — and, in v0, can also
  interfere with errand's own state (see Receipt trust).
- Honest cleanup: errand promises to remove **all state it owns** —
  workspace, managed processes, temp files, containers. It does not promise
  the job mutated nothing else (see Cleanup).
- The receipt is a diagnostic record, append-only as emitted by the daemon.
  It is honest about its own trust level (see Receipt trust). Never
  overwritten into fiction *by errand*.
- Boring on purpose. One binary, one daemon, one application protocol.
  Files on disk. (One protocol, not one literal socket — the tailnet TCP
  listener and the local Unix socket share one handler stack.)

## Shape: symmetric peers

One Go binary. Every machine that installs it can both delegate and receive;
there is no controller. This is a **symmetric peer-to-peer runner, not a
mesh**: no peer relaying, no gossip, no shared scheduler, no distributed
membership — and none should be accidentally grown. Symmetry describes the
two roles. Explicit `--on local` execution uses the same snapshot and job
lifecycle through the private Unix socket. TCP self-targeting remains rejected;
there is no implicit local fallback. `setup --local` configures a daemon for
same-user socket jobs without a network listener or Errand SSH bridge.

Peers are **explicit** in personal config; `errand peers` probes configured
peers' `/v0/info`; `--where` searches only those. Discovery is scoped, not
scanning: `errand peers discover` asks the caller's own tailscaled for the
node list and probes each online node's errand port with an authenticated
`/v0/info` — never arbitrary hosts, never other networks — and prints exact
`peers add` commands for runners that admit the caller. Probing facts is
implied by holding any errand capability (plus network-level access); no
separate probe grant exists in v0.

`--where` is opt-in client-side placement over personal peer entries. A shared
probe deadline bounds latency and concurrency; matches prefer a free slot,
then normalized occupied/queued capacity, with randomized ties. Installing a
local daemon alone does not include it. Workspace defaults and profiles may
select requirements, but cannot introduce transport authority. Fixed `--on`
and `--url` selections override requirements and retain their normal path.

Requested tool facts are measured in the runner's base job environment;
Docker and Podman must answer `info` using only the daemon's executable and
base environment, never submitted PATH or environment values. Admission checks
executable access in the job PATH and requires runtime paths to resolve to the
same file as the daemon's. Runtime probes are bounded and run outside the
admission mutex, after replay, quiescence and capacity checks. Those checks are
repeated after probing before reserving capacity. Requirements are
part of the submission digest and receipt. An already admitted job's replay
is answered from that job, even if facts have since changed. Only a definite
pre-admission capacity or requirements refusal permits trying another peer;
a transport failure after submission begins never permits cross-peer retry.
There are no CPU/memory reservations, global queues, or post-admission moves.
Persistent workspace creation can select a host, but continuing a workspace
requires a pinned target. See [selection details](CONFIGURATION.md#automatic-runner-selection).

`errand access [list|add|remove|deny|undeny]` inspects or edits the local runner
config's `allow_users` and `deny_users`. It never changes a remote peer or
active service. Activation requires a restart. Exact `deny_users` matches override both allowlist entries
and tailnet capability grants. Grants remain saved, so `undeny` restores their
effect. SSH access remains separate. See [runner access](CONFIGURATION.md#runner-access).

`errand doctor` checks this installation, any configured local runner, effective
run configuration, and a bounded info probe of the selected peer when one exists.
It checks required environment names before contacting that peer and keeps
values out of diagnostics. Local checks continue if run configuration fails. It is read-only;
a successful info probe does not establish submission permission or validate
the proposed snapshot or command. See [doctor checks](CONFIGURATION.md#diagnose-the-selected-runner).

For SSH peers, doctor first checks non-interactive access and remote executable
resolution. On a configured runner, doctor reuses setup's service-status and
socket-probe machinery as the service user. It checks saved runner
configuration, binary/PATH availability, socket permissions and responsiveness,
Tailscale identity-provider readiness, and Linux user-service persistence.
Local runner checks activate for a saved runner config, an installed or loaded
user service, an existing socket, or explicit `--config PATH`. A client-only
machine skips those checks; a configured runner's missing socket or stopped
installed service is an error. No outbound peer is a skip, while invalid peer
preferences remain errors. `--on` retains its usual override semantics.
It reports custom service-manager and command-line override limitations explicitly.
Fetch supports exporting retained remote values to a new directory with
`--output` (`-o`), using the same retained bundles as staging and application.
Artifact declarations retain selected generated paths even when input
selection ignores them, while keeping the existing fetch/apply lifecycle.
[Named caches](NAMED_CACHES.md) preserve explicitly declared directories across
jobs using real workspace directories and hardlinked files, with clone/copy
fallbacks. All tools use the same mechanism; no tool detection or configuration
injection occurs. Durable per-job holders permit concurrent workspaces and protect
backing storage from GC. Commands must cooperate with shared inode writes and
handle their own path portability. Successful settled jobs publish changed trees;
unchanged readers do not replace newer snapshots. Cache paths remain excluded
from input snapshots and retained results. `df` reports the last GC measurement;
`gc cache` measures and collects idle entries by TTL and budget.

**Platforms:** Linux and macOS are the v0 targets for both roles; Windows
is a design constraint, not a v0 deliverable — the protocol and job model
assume nothing POSIX-only. The milestone 1 host backend uses a process group
plus an inherited per-job scope marker so it can find descendants that create
new sessions on Linux and macOS. Native cgroup scopes and Windows Job Objects
remain backend-specific follow-on work.

```
errand -- cargo test                  # configured default peer
errand --on cabal -- nix flake check  # named peer (personal alias)
errand --where kvm,arch=amd64 -- ...      # facts-based selection among peers
```

Facts (arch, OS, CPU count, /dev/kvm, and installed tools) are measured
with `observed_at` timestamps. Memory, disk, GPU and tool-version
requirements are not part of the current selector. Client-side they are
selection hints; **the daemon revalidates them as requirements at
admission** against the actual job user — `/dev/kvm` must be openable, a
container runtime must actually respond, not merely sit on PATH.

## Transport and identity

Two remote transports and a direct local socket path share one peer
abstraction. Remote access requires an explicit, revocable, directed grant:

1. **Tailnet (preferred).** Daemon binds the host's tailnet address.
   Callers are identified via destination-scoped WhoIs; the runner reaches
   tailscaled through whichever provider it discovers: the LocalAPI Unix
   socket (Linux `tailscaled`, or the open-source macOS daemon) or the
   `tailscale` CLI (the only path into the standalone macOS app, which
   cannot scope capabilities and therefore authorizes by allow list only).
   Destination-scoped capabilities require Tailscale 1.100 or newer; older
   or unversioned LocalAPI daemons fail closed. errand stores zero credentials
   in this mode.
2. **SSH.** The client speaks the same versioned HTTP protocol over an SSH
   session (`ssh HOST errand _stdio`), which the runner bridges to the
   daemon's **Unix socket**. Identity there is the kernel's: peer
   credentials (`SO_PEERCRED` / `LOCAL_PEERCRED`) must match the daemon's uid.
   The socket and its state-directory parent are private to that account.
   SSH's `known_hosts` pins the runner and `authorized_keys` controls who may
   log in as the runner account, so errand owns no keys or pairing state.
   Peer configuration may set `remote_command` to an absolute Errand binary
   path when the non-interactive SSH `PATH` does not contain it, and
   `remote_socket` when the runner was started with a non-default config,
   state directory, or socket path.
   Set `transport = "ssh"` for an SSH-only runner with no Tailscale.
   `transport = "tailscale"` disables the SSH bridge and local job operations;
   the private socket retains health and setup access. Legacy configs without
   `transport` use `listen = "none"` to select SSH-only operation. The Unix
   socket is the sanctioned loopback route; the TCP listener still refuses
   loopback and self-target connections, which WhoIs cannot identify.

   **The edge is directed** on both transports: on the tailnet from the
   grant's `src` to `dst`, and over SSH through access to the runner account.
   In errand vocabulary the sides are the **caller** (may submit) and the
   **runner** (accepts). A bidirectional relationship is two one-way grants.

3. **Local (amendment, 2026-09-07).** `--on local` connects directly to the
   daemon's private Unix socket with the same kernel-verified OS-user identity
   as the SSH bridge. `transport = "local"` disables the TCP listener and
   refuses Errand SSH bridging while allowing local jobs. Plain setup preserves
   this preference. This is not a restriction on an existing same-account SSH
   shell, which can access the socket or change daemon settings. Workspace
   preferences cannot select the built-in local target without personal opt-in,
   a selected profile choosing local, or an explicit CLI selection.

No additional remote transport. No tailcat mode: control-plane-less tunnels
would discard the identity story errand depends on.

### Tailnet authorization, precisely

Network access and application capability are separate layers. Without an
`ip` grant the connection never reaches errand (denied by Tailscale); with
network access but no errand capability, errand returns 403. Both are
required:

```jsonc
"grants": [{
  "src": ["autogroup:member"],
  "dst": ["tag:errand-runner"],
  "ip":  ["tcp:7443"],
  "app": {
    "lydakis.dev/cap/errand": [
      { "actions": ["submit", "read-own", "kill-own", "forward-own", "manage-caches", "gc-own"] }
    ]
  }
}]
```

The capability carries an **action schema from day one** (not a boolean):
`submit`, `read-own`, `kill-own`, `forward-own`, `manage-caches`, `gc-own`,
and later `read-all`.
Matching grants are additive; errand merges capability objects
deliberately (union of actions). A nonempty exact `deny_users` login match is
checked first and refuses authorization even when `allow_users` also matches.
Denials are loaded at startup; saving a policy edit alone has no live effect.

Authorization is checked on submission **and on every** logs, fetch, forward,
signal, kill, and listing request. Revocation prevents new control, retrieval,
and forwarding; it does not retroactively kill an already-admitted job (that
would be a different guarantee, possible later). Active forwarding requests
end when their transport connection closes.

### Ownership

`read-own` / `kill-own` / `forward-own` need a defined owner principal:

- **Tailnet:** the authenticated Tailscale *user* when WhoIs provides one
  (so a job submitted from the phone can be attached from the laptop),
  otherwise the exact node identity.
- **SSH / local:** the kernel-attested daemon uid on the Unix socket, as
  `local-user:<uid>`. Any SSH session or shell for that uid is the same owner.
- Cross-transport or manually grouped identities are not supported in v0:
  a job submitted over the tailnet is not owned by the same person's local
  uid, and vice versa.

`admission.json` records the user identity and the exact device identity
(tailnet), or the uid and username (SSH/local), even when ownership keys
off only one.

### Job handles are peer-qualified

In a controllerless system a bare ULID doesn't say where the job lives. The
canonical handle is `peer/ulid`:

```
job cabal/01K4Q8ZJ2M...
```

Printed handles (especially for detached jobs) are always peer-qualified. A
configured peer prints its local alias and therefore requires the same alias
on another initiator, or an explicit `--url`. A raw URL retains its scheme and
port in the handle. A bare ULID resolves through `--on`, `--url`, or the
configured default peer. Unknown aliases and conflicting `--on`/`--url`
selectors fail locally rather than being guessed as network hosts.

## Execution backends and isolation — separate axes

Backends provision a toolchain; isolation confines writes. They are not
the same property:

| Backend | Toolchain | Filesystem confinement |
|---|---|---|
| host | target's own tools | none |
| container (rootless OCI) | the image | ordinary writes limited to declared mounts |
| nix devshell | reproducible from flake | **none** |
| Atlas environment (future) | environment's own | strong boundary |

Host and nix jobs are **trusted execution**: they run with the job user's
full powers. The container backend constrains ordinary filesystem writes to
the workspace and declared mounts — it still consumes CPU, memory, disk,
and network, can mutate declared caches, and shares the host kernel. That
is cleanliness for trusted code, not containment of hostile code.

Backend-specific networking sits behind one job-endpoint seam:

```go
type JobEndpoint interface {
    DialTCP(context.Context, uint16) (net.Conn, error)
}
```

The host and nix adapters dial the runner's loopback network while the job is
running. That network is shared: Errand cannot claim the selected job owns the
listening socket, and concurrent host jobs cannot both bind the same port. This
matches the trusted host execution model, where a submission grant already
permits the job to access runner-local services. Container and future Atlas
adapters instead dial loopback inside the job's network environment. The CLI
and tunnel transport do not depend on those runtime details.

Per-project defaults (in the repo; backend and image settings below remain
planned configuration):

```toml
# .errand.toml
[workspace]
root = true                    # this directory is the snapshot boundary

[changes]
apply_on_success = true        # apply after clean successful completion

[artifacts]
paths = ["reports"]            # extra retained outputs

[run]
peer    = "mac-mini"           # optional convenience; alias is personal
backend = "container"
image   = "rust:1.86"          # receipt records the resolved digest

[env]
set = { CI = "1" }

[profiles.debug.env]
pass = ["RUST_BACKTRACE"]      # opt in with --profile debug

[caches]
compiler = "target"            # reusable runner-local build directory
```

Personal aliases, addresses, and defaults live in
`~/.config/errand/config.toml`. A workspace may prefer an alias with `run.peer`;
it cannot define that alias's transport. Run resolution uses explicit CLI,
then an explicitly selected profile, then selected workspace preferences,
then personal defaults, then safe defaults.
Unknown workspace peers fail instead of falling back. `errand config [--json]`
uses the same resolver to explain the effective values without networking or
resuming automatic applications. See [configuration](CONFIGURATION.md) for the
currently supported fields. `--profile NAME` selects peer, workdir, and apply
preferences from `[profiles.NAME.run]` and `[profiles.NAME.changes]`. A selected
workspace definition replaces a personal profile of the same name entirely;
profiles are never selected automatically and cannot define transports or
snapshot boundaries.
For `--no-snapshot`, the current directory is the configuration root, so an
ancestor marker cannot silently choose a peer or apply policy for an empty workspace.

Environment defaults to **nothing forwarded**: target's PATH, plus `pass`
by name and `set` literals. Ambient variables require personal configuration,
an explicitly selected profile, or CLI `--passenv`. Nonempty top-level
workspace `env.pass` is rejected; repository defaults cannot authorize access
to the caller's environment. An empty list can clear inherited forwarding.
Secret-designated values and value-derived hashes are not written into the
receipt. Only names and provenance are retained.

### Cleanup, honestly

When a job ends (success, failure, kill), errand removes everything it
owns for that job: its ephemeral workspace, process scope, and temporary state.
The host scope finds ordinary descendants even when they call `setsid`; it is
lifecycle containment, not a security boundary against hostile code that
deliberately scrubs the inherited marker. `result.json` records `cleanup_ok`
separately from the exit code, and errand never reports pristine when scope
inspection or cleanup failed.

Persistent state has separate lifecycles:

- **Persistent workspaces** keep working files across jobs after explicit
  creation. They are measured by `errand df` and removed by `errand workspaces rm`,
  independently of job and cache GC.

- **Named caches** — errand-owned writable directories with explicit
  lifecycle: declared in config, measured by `errand df`, removed by
  `errand gc cache`. Scoped to the authenticated owner and client checkout.
- **Backend stores** — container image layers, the nix store. Managed by
  the runtime, not by `errand gc`; pruning them is the runtime's own
  command, surfaced but never run implicitly.
- **Job state** — runtime state is removed per the contract above. Receipts
  remain until their owner explicitly applies a bounded `errand gc jobs`
  policy. New job IDs must carry a ULID timestamp from the preceding 24 hours,
  with one hour of allowed future clock skew. The runner durably advances a
  high-water clock that never moves backward across restart. Replay-only
  collection markers expire after 25 hours. Markers for jobs with retained
  workspace changes are scoped to the originating client and retain that minimum
  lifetime; successful local reconciliation acknowledges the marker so it can
  retire. Unacknowledged change markers expire after 30 days, bounding state
  left by lost clients. The markers are minimal and non-secret, and neither
  permits a collected ID to execute again.

## The job transaction

### Receipt format (append-only)

`~/.errand/jobs/<ulid>/`:

```
spec.json        # versioned, immutable redacted request receipt (argv, env
                 # names and provenance, limits, manifest root)
admission.json   # caller user + device identity, authz result, revalidated facts
execution.json   # argv and, unless PATH was caller-supplied, resolved path
events.ndjson    # append-only lifecycle + control events
io.log           # framed, base64-payload stdout/stderr in daemon-observed order
result.json      # written once at terminal completion
scope.json       # transient recovery marker; retained until runtime cleanup
workspace/       # ephemeral jobs only; deleted at cleanup
changes/         # immutable workspace-change bundle; retained with the job receipt
```

A derived `status.json` may exist as a convenience cache; it is never the
authoritative record.

### Receipt trust (v0)

Receipts are **append-only as emitted by the daemon**. They are diagnostic
records, not tamper-evident against local administrators or against jobs
running as the same OS user — in v0 the job state lives under the same
account that runs host and nix jobs, so a hostile job could corrupt
receipts, other jobs' state, or the daemon itself. This is accepted for a
personal tool running trusted code, and it is stated rather than hidden.

The upgrade path is real privilege separation, not a shared "errand user":
`errandd` owns job records, peer keys, and configuration; jobs run as a
separate ephemeral worker account that cannot read or modify the daemon
state directory. That lands post-v0 unless adversarial receipt integrity
becomes a requirement — in which case it belongs in milestone 1.

### Invariants

- **At-most-once admission.** The client generates the job ULID and a
  canonical request digest, submitting with `PUT /v0/jobs/<ulid>`.
  During one daemon lifetime, same ID + same digest returns the existing job;
  same ID + different digest returns 409 Conflict. An environment-free receipt
  can reconstruct that identity after restart. A receipt with declared
  environment values cannot do so without persisting a value-derived verifier,
  so every same-ID retry after restart fails closed with 409. Errand never
  automatically reruns a job whose
  execution state is ambiguous (e.g. after a daemon restart between
  "starting" and process creation) — ambiguity is reported, not replayed.
  Network retries therefore cannot duplicate a command; that is the whole
  user-facing promise, and no stronger distributed-systems claim is made.
- **Ordered, resumable logs.** The authoritative stream is framed events
  `{"seq":42,"stream":"stdout","data_b64":"..."}` — SSE is a text
  protocol, so payloads are base64. Ordering is **daemon-observed order**:
  there is no intrinsic total order between two pipes, only the order the
  daemon drained them. Reconnect resumes via `Last-Event-ID`. Plain
  `stdout.log`/`stderr.log` are derived views.
- **Separate outcomes.** `result.json` distinguishes
  `{exit_code, signal, changes_ok, cleanup_ok, logs_complete}` — a job can
  succeed while collection or cleanup fails, and the receipt says which.
- **Signals behave like signals.** Ctrl-C forwards SIGINT; a second Ctrl-C
  or `errand kill --force` escalates. If contact is lost mid-signal, the
  client prints the peer-qualified handle and admits the process may still
  be running.
- **Attachment is local and reversible.** On an interactive terminal, Ctrl-D
  stops local log following and any local port listeners for that attachment,
  prints the reattach command, and exits 0 for successful detachment. It never
  signals the remote job. Non-terminal EOF is ignored so scripts retain
  attached exit-code fidelity unless they explicitly use `--detach`.
- **Durability and reconciliation:** jobs survive *caller* disconnection.
  Before starting a process the daemon persists an unguessable inherited
  scope marker. After a daemon restart it terminates surviving scoped
  processes, removes the workspace and transient scope record, and writes a
  durable `ambiguous` result. It never replays the command and never treats
  the absence of a survivor as evidence that the command did not start. A
  target reboot is reconciled with the same conservative ambiguous outcome.
  If terminal cleanup was incomplete, the retained scope marker and workspace
  are retried on later daemon starts without rewriting the immutable result.

### Attached TCP forwarding (milestone 4.5 amendment, 2026-09-03)

Port forwarding extends an attached job session without becoming durable job
policy or another top-level command:

```text
errand --forward 3000 -- pnpm dev
errand --forward 8080:3000 -- pnpm dev
errand attach --forward 3000 HANDLE
errand attach --forward 8080:3000 HANDLE
```

`--forward [LOCAL:]REMOTE` is repeatable. Omitting `LOCAL` uses the same port
locally. The run form is shorthand for submitting and opening the initial
attached session with those forwards. A job may be submitted without any
forwards and gain or change them on any later attachment. Forward mappings are
local session state: they are not written to `spec.json` or displayed by
`status`. `[session] forward` defaults and `[profiles.NAME.session]` can select
mappings for each new session; `attach --profile NAME` applies only session
preferences and keeps the handle as its target. Each attachment resolves
current configuration rather than remembering submission settings. CLI
`--forward` replaces the configured list; `--no-forward` clears it. See
[session configuration](CONFIGURATION.md#session-forwarding).

The client binds both IPv4 and IPv6 local loopback when the platform supports
them. It binds every requested local port before submission or attachment so a
collision fails without admitting a new job or partially opening a session.
Each accepted TCP connection creates one separately authenticated,
owner-checked, full-duplex request to the runner.
The runner accepts it only with `forward-own` and only while the named job is
running. For the host backend, that job is an ownership and liveness gate, not
a network boundary: the tunnel can reach any runner-loopback service. Staging,
queued, and terminal jobs refuse tunnel connections immediately. The local
listener remains open, so clients may retry after the job starts.

Detaching with Ctrl-D closes the local listeners and their connections without
signaling the job. Ctrl-C retains the normal attached-job meaning: it sends
SIGINT, a second Ctrl-C force-kills, and the forwarding session closes as the
job settles. A client that wants forwarding after detaching invokes `attach`
again with the desired mappings. `--detach --forward` is rejected because no
attached client would remain to own the local listeners. This includes
configured forwards; use `--no-forward` to submit that profile detached.

There is no readiness probe. If the application is not listening, the accepted
local connection closes without a noisy session diagnostic; the listener stays
available for the next connection. Bytes are relayed without application-level
inspection, so HTTP, WebSockets, and development-server hot reload need no
protocol-specific behavior. EOF or reset from either endpoint closes the whole
forwarded connection; independent TCP half-closes are not part of the initial
HTTP tunnel contract. Unexpected forward failures are local session diagnostics
and never rewrite the remote process result. Local bind failure on the initial
run occurs before submission.

The initial surface deliberately excludes port inference, automatic browser
opening, reverse forwards, UDP, Unix sockets, SOCKS, HTTPS termination, public
or LAN binds, background local tunnels, and automatic remote-port allocation.
The ordinary two-hour runtime limit and runner capacity rules are unchanged: a
development server occupies one running slot until it exits or is stopped.

Forward mappings and individual TCP connections are not receipt state. The
daemon does not append an event for every browser or hot-reload connection and
does not retain forwarded bytes. It keeps only the transient connection state
needed to close tunnels when the job or request ends.

### Limits

Limits are **fixed at admission and enforced at the relevant execution
phase**: upload size at admission; workspace expansion at unpack; runtime,
log size, and retained-change size during execution and collection. On hitting the
log cap the daemon terminates the job with `limit_exceeded`, preserving a
complete log up to termination; the fidelity contract promises faithful
process output, not best-effort truncation.

The runtime deadline begins when the child starts and remains unchanged through
workspace-change collection. Collection does not receive a fresh runtime budget after the
process exits.

**Concurrency (milestone 3.5 amendment, 2026-08-30).** A runner executes
up to `max_jobs` jobs at once (default 1; concurrency is an explicit
per-runner choice) with a bounded FIFO admission queue of `max_queued`
waiting jobs (default 8; zero disables waiting). Beyond both, submissions
return `busy`; that boundary survives. Admission order and capacity are
reserved before staging, so upload duration cannot reorder jobs. Once staging
succeeds, a durable queued marker commits the admission and every process
start flows through one FIFO launcher. Launch failures therefore produce the
same durable receipt whether or not a slot was initially free. A signal or
kill accepted before process start settles durably as killed before the
control request succeeds.

Queued jobs appear in listings as `queued`. On daemon restart, a queued marker
without a process-scope record proves the command never started; the daemon
settles that job with a never-started result and does not replay it. A scope
record still means execution may have begun and retains the ambiguous restart
semantics. The runtime limit starts at launch; time spent queued is unbounded.
The queue remains deliberately simple: no priorities, bin-packing, or
cross-peer scheduling, and errand does not referee CPU or memory contention.
Both limits are per-machine choices for the operator who knows its workloads.

## Workspace snapshot

- Snapshot-root discovery precedence is explicit `--workspace-root PATH`, the
  nearest ancestor `.errand.toml` with `[workspace] root = true`, then the
  current directory. The selected root must contain the invocation directory;
  the latter becomes the default remote workdir relative to that root. The
  root marker defines a boundary, not permission to ship it. Automatic
  discovery trusts only caller-owned markers in caller-owned directories that
  are not group- or world-writable; intentionally shared workspaces use the
  explicit flag.
- Automatic selection is limited to Git worktrees. A non-Git directory must
  contain `.errandignore` or use the explicit `--include-all` override.
  Filesystem roots are always refused; the user's home directory requires the
  override even when a policy file exists. The client prints the selected file
  count and total bytes before admission.
- `--no-snapshot` explicitly skips local content inspection and transfer. The
  client still records the invocation directory's identity and the empty
  manifest root so retained changes can be applied only to that originating
  workspace. The job receives an errand-owned workspace, but it starts empty,
  so a non-root `--workdir` is rejected locally.
- Selection uses explicit `.errandignore` rules when present, otherwise Git's
  tracked, untracked, and ignore hierarchy. The effective ignore rules are
  frozen into the request for new-path retention.
- The snapshot is consistent or refused: packing builds a manifest of
  path, type, mode, size, and content hash; files that change mid-pack are
  detected and the snapshot **fails with a retry prompt** rather than
  shipping a mixture of moments. The manifest root hash is recorded in
  `spec.json` (and is the natural basis for later content-addressed sync).
- Git submodules are rejected unless an explicit `.errandignore` policy is
  used to define a recursive filesystem snapshot. A gitlink is never sent as
  a silently empty directory.
- `.git` is **not** shipped by default (size, history disclosure); jobs get
  `ERRAND_GIT_COMMIT` / `ERRAND_GIT_DIRTY`, with an opt-in to include the
  repository database.
- Archive extraction (both directions) rejects absolute paths, `..`,
  symlinks escaping the workspace, and unsafe hardlinks. A strange archive
  must not write outside `workspace/`.

## Persistent workspace lifecycle

Persistent workspaces require explicit `workspaces create NAME`. Ordinary jobs
remain ephemeral. `--workspace NAME` selects an existing caller-owned workspace;
it never creates one or uploads the invocation's current local files.

Creation publishes a verified working tree, an immutable base snapshot, and
metadata under a separate runner `workspaces/` store. Human names are scoped to
the authenticated owner; opaque IDs prevent deletion/recreation from retargeting
an in-flight request. Listing and reads require `read-own`, creation and use
require `submit`, and removal requires `gc-own`, with owner checks on every path.

A durable job lease precedes execution in the tree's stable directory. It covers
staging, queueing, execution, and process cleanup. Finishing a job releases the
lease rather than deleting or moving the directory. Restart recovery locates
current leases by job ID, cleans surviving processes before releasing them, and
never replays a command. Old receipts without a current lease cannot target a
workspace now used by another job. Uncertain process cleanup or mismatched
directory identity leaves the affected job's lease protected. Membership is a
set of job IDs, including staged and queued jobs. The last member settles named
caches and removes their links before releasing the workspace. A shared cache
lease identity outlives its first job when other members remain; individual job
GC and restart recovery cannot release it early. Cache storage remains
independently managed.
The job receipt durably records its workspace reference before lease publication.
Recovery validates that reference against the current lease, so a broken sibling
record cannot prevent unrelated job cleanup. Terminal pre-launch failures also
retry lease release on restart. Unreadable lease state protects the affected job
while the daemon continues serving other jobs. Inventory errors remain visible
rather than presenting incomplete storage totals as complete.
Tree copying, traversal, cache-path settlement, and deletion happen outside the
global metadata lock. A cache binding replaced by a command is moved into a
unique `.errand-cache-recovery-ID/` directory in the live tree, preserving its files
without preventing subsequent cache binding.

Jobs can execute concurrently in one persistent workspace. Short lifecycle
operations serialize per workspace, while user commands and retained-change
collection may overlap. No read-only classification or file-write locking is
attempted. The runner's ordinary concurrency and queue limits still apply.

Persistent jobs use their process group plus an inherited unique scope marker.
Shared workspace and cache directories cannot establish process ownership and
are never used to select processes for cleanup. The machine boot identity and
group leader's kernel birth identity are persisted after launch, supplementing
markers for macOS platform binaries whose environment is not visible. Restart
discards groups recorded under an earlier boot and otherwise validates the
leader's identity before signalling. A crash before group publication, a reused
leader PID within the same boot, or a leaderless group whose ownership cannot
be verified leaves cleanup unresolved and the job's lease protected. If group
capture succeeds but its durable write fails, the live daemon stops the command
and releases membership only after verifying process cleanup with the captured
identity; the receipt retains the persistence error. Escaped descendants must retain a visible marker;
this remains cooperative lifecycle containment, not a sandbox.

Workspace metadata accepts the earlier single-job format during recovery and
writes `job_ids` for current membership. A surviving job from the earlier format
retains exclusive access and its directory-based cleanup until recovery completes.
Cache binding changes and final release share a per-workspace lock, so admission
cannot join midway through settlement.
Metadata reads, listing, and unrelated jobs remain independent of that lock.

Each job retains an immutable result relative to the workspace creation base.
The wire request names that initial manifest; its workspace archive carries no
new local files. Job fetch still addresses that immutable result. Application
reconstructs the observed source and uses a directional checkpoint. Removing the
live workspace does not remove prior job results, and collecting a job does not
remove the live tree.
This cumulative result supports fetching only the final iteration. It is not a
per-job delta. Previously applied identical content merges without conflict;
subsequent overlapping edits can still require conflict resolution. Changing to
a job-start baseline would require a separate cumulative workspace transfer path
to preserve the final-iteration workflow. Concurrent results describe observed
workspace state, not attribution to a particular job; sibling writes can cause
collection to fail its verification. A final job after writers stop gives a
stable cumulative result.

Persistent workspaces appear in `df` and are removed only by explicit
`workspaces rm`. There is no automatic workspace TTL in this slice. Workspaces
do not provide isolation from arbitrary processes running as the runner OS user.

`df --verbose` exposes owner-scoped per-workspace working/base/metadata byte
counts alongside separate named-cache and job entries. Summary and workspace
detail come from one traversal, which never follows cache symlinks. Counts are
logical file sizes, not unique physical allocation. `ps --workspace` resolves
names to current IDs and filters owned jobs before the listing cap; IDs can
still select retained receipts after workspace removal.

## Workspace changes

Retention (target-side) and application (client-side) are separate. After the
process and its scope settle, the target compares the final workspace with the
submitted manifest and durably retains the minimal roots of every creation,
modification, and deletion. This happens on successful and failed commands and
requires no path declaration. Every submitted path remains eligible so its
modification or deletion is observable. Newly created paths are eligible only
when allowed by the selection policy frozen into the request during snapshot
preparation. The command cannot widen retention by editing ignore files. For
`--no-snapshot`, the baseline and selection policy are empty, so every
representable generated path is retained.

Retention uses the same representable filesystem boundary as snapshots. Git
metadata, Errand apply transactions, and transient nodes such as sockets are
excluded without invalidating other retained changes.

Attached and detached jobs use the same retention path. Completion reports the
retained-change summary and handle without downloading the bundle unless the
job's submission policy requests automatic application. `--apply` applies only
after the remote process and transaction both succeed; `--no-apply` disables
workspace or personal defaults. That policy is independent of observation:
explicit `--detach` and interactive Ctrl-D hand it to a detached local
completion worker. `attach` follows logs and status without choosing or changing
the policy.

Interrupted workers retain their pending policy but are never restarted by CLI
startup. Once the job finishes, the user explicitly recovers its apply with
`fetch --apply HANDLE` from the originating workspace. A different or
non-matching workspace can stage changes but cannot apply them. Healthy workers
and their transient-error retries continue independently.

`ps`, `status`, and `doctor` inspect saved state and existing worker ownership
without launching workers or creating client state. An unfinished policy
without an owner is reported as needing recovery. The default job list retains
interrupted applies even when remote execution has finished.
Worker lease files retain their inode after release so inspectors and starting
workers always observe the same lock; an unlocked file does not imply ownership.

Application is conflict-safe, never silent:

1. Retain the submitted base tree and completed remote tree for every changed
   root.
2. Download both trees into local staging; validate paths, types, and content.
3. Three-way merge the submitted base, current local workspace, and completed
   remote tree entirely outside the working tree.
4. If every selected change merges cleanly, install the complete result through
   same-filesystem renames. A durable local journal rolls back an interrupted
   installation or completes its state record before discarding original files.
5. By default, any conflict leaves the working tree untouched, retains staging,
   and reports the conflicting paths.

`fetch --apply --conflicts` is the explicit exception to step 5. It installs
clean changes and standard text conflict markers while leaving binary and type
conflicts at their local values. It retains the staged base and remote values,
reports every unresolved path, and exits nonzero. Errand provides no conflict
index, resolution commands, or continuation lifecycle.

This is a path-based merge with Git-compatible text merge behavior. It does not
attempt rename detection or maintain an Errand-specific conflict index.
Git is otherwise optional. The client invokes `git merge-file` only when apply
must merge a text file changed on both the local and remote sides; a missing
binary aborts safely before the installation transaction.

Client-side workspace identity and staging records are keyed by runner endpoint plus job
ID. Pending apply journals are never collected. Pre-admission records follow an
explicit local GC cutoff; unresolved submitted records receive a 30-day safety
window before an explicit `gc changes` may retire them.

`fetch --output DIR` exports the selected remote values into a new directory,
preserving workspace-relative paths, file modes, and safe symlinks. It requires
an existing parent and refuses every existing destination. Contents are
verified in private temporary storage on the destination filesystem before
an atomic rename that cannot replace another entry. Export holds the local
bundle transfer lock throughout, so local change GC cannot remove its source.
It requires no originating workspace identity, does not record an application,
and works after failed commands. It cannot be combined with apply or conflict
materialization. Deleted paths have no exported value; their metadata remains
available through plain fetch. A partial path export can contain symlinks to
unselected paths; the targets are not implicitly copied.

Explicit `artifacts.paths` declarations (or repeatable `--artifact PATH` flags)
are frozen in the spec's selection policy and recorded in the receipt. Only
retention consumes them: input ignore matching stays unchanged. They name exact
workspace-relative paths, with directories selecting descendants. Ignored
ancestors are traversed only as needed, and unrelated ignored siblings remain
excluded. Missing declarations are allowed; existing retention limits, reserved
metadata exclusions, safe symlink rules, and cleanup requirements still apply.
`--no-artifacts` clears configured declarations. Declared outputs use the same
bundle, three-way merge, and local collision refusal as ordinary changes.

### Exit status: two layers

- **Process result:** the remote exit code or signal, recorded exactly in
  `result.json`.
- **Transaction result:** whether execution, workspace change retention, and
  cleanup completed.

CLI behavior: when the transaction succeeds, the CLI exits as the remote
process did. If the remote process exits 0 but change retention or cleanup
fails, the CLI returns an errand-level nonzero status and prints
`remote_exit=0` — otherwise
`errand -- cargo build && ./target/release/thing` would happily run a stale
binary, which violates local-likeness worse than remapping the status. If
contact is lost before a terminal result, the CLI returns an errand-level
failure and prints the resumable peer-qualified handle. A nonzero remote
exit is returned as-is, with secondary transaction failures reported
separately.

## Execution context receipt

The receipt records the execution context errand controlled or directly
observed — it is **not** an attestation of everything the process
transitively ran, loaded, or fetched (that would be execution tracing, a
different product). Recorded: argv and, unless PATH was caller-supplied, the
top-level resolved executable path; target platform; container image digest;
nix flake lock hash and resolved derivation; and explicitly configured version
probes. Raw PATH and value-derived PATH hashes are never persisted. Nothing
vaguer is promised.

## CLI surface (v0)

```
errand [--on X | --where facts] [-d | --detach] [--apply | --no-apply] -- <cmd...>
errand setup [--max-jobs N] [--allow-user LOGIN]...
             [-f | --force] [-n | --dry-run] [--print-acl]
errand peers [--on X | --url URL] [--json] # runner status, capacity, and capabilities
errand peers add NAME HOST      # verify first (403 → accurate allow-list remedy), then record
errand peers remove NAME
errand peers discover [-a | --all] # runners on the caller's own tailnet; read-only
errand ps [-a | --all] [-n N | --last N] [--on X] [--json] # N <= 200
errand attach <peer/ulid>       # replay logs and follow to completion
errand fetch [--apply [--conflicts] | -o DIR | --output DIR] <peer/ulid> [path]
errand push --workspace NAME [--on PEER | --url URL] [--apply [--conflicts]] [path]
errand kill [-f | --force] <peer/ulid>
errand df [--on X] [--json]    # fleet storage; read-own
errand gc cache --on builder [--dry-run]     # shared cache policy; manage-caches
errand gc jobs --on builder --older-than 30d # caller-owned clean terminal receipts
errand gc changes --older-than 30d # local workspace identities and downloaded staging
errand gc all --on builder --older-than 30d [--dry-run] # selected runner cache/jobs plus local changes
```

Every GC target accepts `--dry-run`. A dry run uses the same eligibility policy
while leaving all persistent state unchanged, including cache files, receipts,
reconciliation markers, local lock files, permissions, and the admission
clock. Local staging that cannot be sized without widening permissions is
reported as a failed preview and left untouched.

Frequent run options use established short forms: `-d` for `--detach`, `-e`
for `--env`, `-w` for `--workdir`, and SSH-style `-L` for `--forward`. GC uses
`-n` for `--dry-run`, `errand kill` uses `-f` for `--force`, and peer
management follows those same aliases plus `-a` for `discover --all`. Routing,
transport details, workspace mutation, and snapshot-boundary options remain
long-form.

`errand setup` acquires an expiring lease from the local daemon before changing
config or service files. The daemon grants it only while idle and atomically
refuses new admissions until restart, so setup cannot race a newly submitted
job. If an existing local socket cannot be reserved, setup refuses the
restart. Its generated SSH peer block includes the effective `remote_socket`
and an absolute `remote_command` unless setup proved that
`/usr/local/bin/errand` resolves to the installed executable.

Without `--detach`: streams, exits per the two-layer status rule — drop-in
for scripts. With `--detach`: prints the peer-qualified handle and returns.
A terminal user can press Ctrl-D while running or reattached to detach the
local follower and later attach again; Ctrl-C continues to interrupt the
remote process. A detach exit of 0 confirms only the local detach action, not
the eventual job outcome. Detaching never changes a job's `--apply` or
`--no-apply` policy; automatic application continues in a detached local worker.
A bare ULID is resolved through `--on`, `--url`, or the configured default
peer. Alias-qualified handles require the matching peer configuration;
URL-qualified handles retain the concrete scheme, host, and port. An explicit
`--url` may route an alias-qualified handle elsewhere, and the client then
reports the effective URL rather than preserving a misleading alias.

## Protocol

Versioned HTTP+JSON: `PUT /v0/jobs/<ulid>` is idempotent;
`GET /v0/jobs` returns the caller's bounded newest-first listing, while
`GET /v0/jobs?active=1` filters active jobs before applying that bound;
`GET /v0/jobs/<ulid>` returns status plus the durable non-secret request
details used by `errand status`; SSE with event IDs powers
`GET /v0/jobs/<ulid>/logs?from=<sequence>`; the signal and kill routes control owned
jobs and return `204 No Content` on success; `POST /v0/snapshot/diff` negotiates missing snapshot blobs;
`POST /v0/workspaces/<id>/push/diff` negotiates the same cache for an owned
workspace and establishes support for partial push archives. Push reconstructs
and verifies the complete source before staging its delta; a missing cached
body returns `snapshot_cache_miss` before staging, allowing a full-upload retry.
Runners without this endpoint, or with snapshot caching disabled, return 404
and receive full archives. Both submission and push share the negotiation and
single full-upload fallback policy. Negotiation deduplicates content hashes;
its response limit scales with the requested hashes so a valid cold manifest
does not exceed an unrelated fixed response cap. Cache corruption is a miss
even if deleting the bad cache entry fails; destination failures and cancellation
remain errors. Upload ingestion caches each unique body once and continues past
an unavailable source, reporting the first failure. Push staging uses the bulk
operation response deadline because verification and durable staging continue
after the last request byte arrives;
`GET /v0/storage` reports caller-visible storage, including snapshot and named caches;
`POST /v0/cache/gc` prunes snapshot blobs and idle named caches;
`POST /v0/jobs/gc` applies bounded owner-scoped receipt retention;
`GET /v0/jobs/<ulid>/changes` transfers the immutable retained workspace-change bundle;
`POST /v0/jobs/<ulid>/ports/<port>/connect` carries one authenticated
full-duplex TCP connection in its request and response bodies;
`GET /v0/change-reconciliation` pages through durable owner- and client-scoped
collection markers so local change GC can reconcile after a lost deletion
response; `POST /v0/change-reconciliation/ack` releases the change hold after that
reconciliation while preserving the replay-prevention lifetime; and
`GET /v0/info` returns facts. A negotiated blob disappearing before
submission returns the machine-readable `snapshot_cache_miss` error code so
the client can retry the same job ID with a complete snapshot. Curl-debuggable;
the route prefix is the request-protocol version; receipt and change-bundle
versions apply only to their persisted formats. Executable versions are
diagnostic information. Peers, doctor, and setup report version differences
without blocking commands. Matching versions are recommended when diagnosing
unexpected behavior. There is no version negotiation or alternate behavior for
older formats. Updating the executable requires restarting the daemon.
Development builds can use an explicit version label to identify them
(`go build -ldflags "-X main.version=LABEL" ./cmd/errand`).

## Non-goals

- Not a CI system: no triggers, no pipelines, no DAGs.
- Not interactive: no stdin, no PTY, no full-screen programs in v0.
- No reverse port forwarding, UDP forwarding, public listeners, or persistent
  service exposure. Attached TCP forwards are client-initiated and ephemeral.
- Not a security boundary against hostile code — see the grant-equals-shell
  belief and Receipt trust. Containment of hostile workloads is Atlas's
  job.
- No web UI. No wake-on-LAN, offline queueing, or store-and-forward.
- No arbitrary-host discovery or scheduler-style fan-out. `errand ps` may
  query the caller's finite, explicit configured-peer set; partial failure is
  reported with a nonzero exit status.
- No arbitrary-host scanning; discovery is limited to the caller's own
  tailnet node list and the errand port, and never writes config by itself.
- No execution tracing / attestation; the receipt claims only what errand
  observed.

## Roadmap

### Implemented on main

- Remote command execution over Tailscale and SSH, with workspace snapshots,
  resumable logs, receipts, admission replay protection, and bounded job queues.
- Local execution and local-only daemon setup.
- Automatic change retention, artifacts, fetch, export, apply, and explicit
  conflict materialization, including results from failed jobs.
- Attached TCP forwarding, content-addressed snapshot caching, and named caches.
- Explicit persistent workspaces with concurrent jobs, directional push/fetch,
  recovery, and storage accounting through `df` and `gc`.
- Configuration precedence, profiles, environment-forwarding consent, access
  controls, and read-only diagnostics.
- GitHub releases and Homebrew distribution.
- Opt-in `--where` selection among personally configured runners, with capability
  checks, job-capacity ranking, and admission-time revalidation.

Unreleased changes since v0.3.0 include snapshot and startup performance
improvements, a workspace transfer locking fix, named-cache directory-tree
changes, and `--where`.

### Next: release and use

Prepare v0.4.0 from the reviewed changes, verify CI and release packaging, publish
through GitHub and Homebrew, then upgrade client and runner installations.

After release, prioritize real workloads, adoption, and measured problems.
Changes to runner selection should follow evidence about placement decisions,
queueing, and startup latency.

### Deferred until needed

- Container and Nix backends need a concrete workload that justifies managing
  execution environments and their lifecycle. Named caches already work with
  the host backend independently of containers.
- Resource reservations and richer requirements, such as memory, GPUs, or tool
  versions, should follow workloads that job-slot balancing cannot serve.
  The current CPU predicate describes machine capacity; it does not reserve cores.
- Privilege separation between the daemon and workers remains future work.
  Errand's current trusted-host model does not contain hostile code.

An agent CLI wrapper can build on Errand's jobs and persistent workspaces as a
separate project. It would own harness-specific events and thread resumption.
None of these options is a scheduled next milestone.

## Persistent workspace transfer design

Directional transfer connects an originating checkout and a persistent workspace.
The following contracts are implemented. Attaching to a job remains observation.

The transfer interface mirrors fetch: plain `push` stages remotely,
`push --apply` merges remotely, and `push --apply --conflicts` permits conflict
materialization there. Fetch provides the corresponding local operations.
Without `--conflicts`, a new conflict leaves selected destination files untouched.
Existing conflict markers are ordinary file contents and may travel in either
direction. No conflict index, resolution lifecycle, or transfer `--force` is
provided. Transfer checkpoints and retry handling cover partial conflict
materialization as well as clean application.

`push --watch` repeats this operation after local filesystem notifications;
`--apply` remains explicit. The client installs native watches before its initial
push, batches saves for 5 ms (at most 25 ms), and runs one transfer at a time. It reconciles edits made
during a transfer afterward. Idle sessions do not scan or hash the tree.
With an explicit `.errandignore`, ordinary content writes refresh hinted files.
Fresh policy bytes and native directory identity, mode, mtime and ctime evidence
revalidate selection without enumerating all files. Structural changes, atomic
saves, watcher overflow, Git-driven selection and preparation expiry use
full selection. Expiry is checked when preparation runs, without an idle scan
timer. Events arriving during preparation stay queued. Frozen bodies
are still verified against their manifests. Session-local hash reuse requires
unchanged inode identity, size, mode, mtime and ctime.
Cancellation drains the active transaction. A recovered apply is completed with
its original identity before reconciling current files. Conflicts and policy or
workspace identity changes stop the session; transient transport failures back off.

`GET /v0/workspaces/<id>/push/base?client=<id>` negotiates incremental source
uploads and returns that owner's retained directional source checkpoint. Both
ordinary push and watch can send a `PushRequest.delta` with `source_root` instead
of the full manifest through the versioned `/push/delta-v1` endpoint.
The daemon reconstructs metadata from the retained checkpoint, verifies the full
root and canonical delta, and checks the complete source against workspace limits.
Only changed source bodies are frozen and uploaded. Small deltas (up to 64 KiB
of file bodies) skip blob negotiation to save a round trip. The upload gate is
released during network I/O; staging rechecks the checkpoint under the apply gate
and rejects a stale baseline. Live runner contents never supply unchanged source
entries or merge bases. Local retry state retains the full manifest and frozen
delta bodies; publication and apply retain the existing durable receipts.
Runners without the base endpoint receive ordinary full-manifest push requests.
A runner that loses delta support after negotiation rejects the versioned upload;
the client never sends that partial source to the legacy full-snapshot endpoint.
A typed checkpoint rejection before staging permits one fresh-source retry.
Uncertain apply replies retain the original request identity.

Prepared source plans own validated metadata and canonical deltas. Staging
reuses them only after recovery and a fresh checkpoint check, retaining normal
body verification, source quotas and durable publication. Persistent fetch uses
the same plan to materialize only changed remote bodies. Workspace descriptor
requests may omit the creation manifest; full reads keep their existing contract.
Creation uploads negotiate the shared verified body cache through separate
snapshot routes, with a full-upload fallback for older runners or explicit cache
misses. Long creation and job uploads use the admission timeout budget.

An internal receiver-side apply receipt records each application.
It binds one application to its owner, destination directory identity, immutable
bundle, selected roots, and conflict option. The existing apply journal records
conflict outcomes alongside installed states, so recovery can persist the receipt
before discarding backups. Retrying that application returns its original result
without reapplying it over later edits; deliberately applying again uses a new
application identity. This also applies to a clean-or-refuse rejection. A conflict
report describes that application, not whether the files still contain conflicts.
Once the outcome is durable, finalization checks the journal and backups without
requiring the installed files to remain unchanged. It then persists a cleanup
checkpoint bound to the transaction directory identity before deleting recovery
data. Retries can finish interrupted deletion even if the journal or some backups
are already gone, while refusing a replacement transaction directory.
Before the outcome is durable, recovery
still verifies installed content before reconstructing a result. A conflict error
escaping materialization is a failed attempt, not a completed refusal; every
outcome is validated before publication. Private receipt storage is checked by
directory ancestry identities, including on case-insensitive filesystems.
Installed states can include markers or preserved destination values and must not
be mistaken for complete acceptance of the incoming source tree.

An internal directional checkpoint records the accepted source manifest for
one stable source identity and receiving directory identity, scoped to its owner.
Each direction has independent progress. A completed apply receipt advances
installed paths outside conflicts to their source values, preserving the previous
base for unselected paths and conflicted subtrees. A conflict in one child does
not discard acceptance of clean siblings: otherwise a later source deletion of
an installed sibling could be mistaken for a destination-only file. Merged
destination values never become the source checkpoint. A content-root directory
mode conflict preserves that entire destination subtree instead of installing
children beneath an unresolved directory. Separately selected directory metadata
updates affect only that entry; independently installed child roots still advance.
Accepted removals and type changes replace the corresponding subtree.

Checkpoint updates consume a revision even when a refusal leaves the manifest
unchanged. Retrying the latest update returns the recorded checkpoint; an older
revision cannot rewind subsequent progress, including when the manifest digest
is unchanged. Before publishing progress, the receipt is durably bound to that
checkpoint relationship and expected revision. It cannot be consumed again at a
new revision, even after intervening updates. Recovery can complete publication
after that binding without reapplying destination files. Retrying creation never
resets an advanced checkpoint. Publication uses the same bounded atomic state
writer as apply receipts and verifies both destination and storage identities
before reporting success. Storage checks retain the requested path as well as
the resolved directory, so retargeting a parent or ancestor symlink is detected
during publication, reads, and retries. The caller must serialize the directional
operation, verify its revision before applying, and bind the receipt to that
relationship. Source identity and expected revision are
integration inputs, not values inferred from job handles or live file contents.

A dedicated internal transfer blob store retains source file bodies by hash,
independently of the evictable upload cache. Retention verifies size and content
before atomically publishing durable private copies, deduplicates identical
bodies, and refuses additional data when its configured capacity is exhausted.
Retries reuse verified stored bodies even after capacity is lowered or their
original source disappears. Only missing bodies need source access. That source
must be a caller-owned, stable staging tree, not an actively edited workspace:
retention may temporarily widen permissions and restores them on return, but a
process crash can leave staging permissions widened. Callers keep staging
unchanged throughout retention. This does not serialize ordinary workspace jobs.
Directories, file modes, and symlinks remain manifest metadata. Reconstruction
verifies retained bodies again and atomically creates a new private change-base;
it never replaces an existing baseline or shares writable hardlinks with storage.
A separate logical-byte limit bounds reconstruction even when many paths refer
to the same body. Missing or corrupt bodies fail without publishing a partial tree.

The store exposes byte/blob accounting and explicit pruning with a dry run. The
caller supplies all checkpoint, staged, and in-flight manifests whose bodies must
stay, under the same serialization as retention and reconstruction. Malformed
manifests, missing bodies, and size mismatches stop pruning before any deletion.
Pruning does not hash pinned content; retention and reconstruction verify hashes
when reusing bodies. Accounting includes abandoned insertion bytes, which count
against capacity until explicitly pruned, but excludes them from blob counts.
Unreferenced bodies and interrupted insertion files can be reclaimed; referenced
bodies have no TTL or
automatic size eviction. Retain bodies before publishing the checkpoint that
references them. The store must live in dedicated private owner-scoped storage
outside working trees; it does not discover relationships or pins on its own.

The transfer session stages immutable source deltas, retains
source bodies before mutation, persists apply intent, and advances the directional
checkpoint only from a completed receipt. Recovery completes that sequence before
another transfer or job admission on the affected workspace. A workspace control
gate coordinates transfers, admission, cache settlement, and removal; it never
serializes already-running user commands. Recovery I/O does not hold the global
workspace metadata mutex, and a damaged workspace does not prevent unrelated
workspaces or ephemeral jobs from starting.

The public interface is `fetch JOB_HANDLE` and `push --workspace NAME`, each with
explicit `--apply` and `--conflicts`. There is no live-workspace fetch or push by
job handle. Creation records the original checkout identity and shared snapshot
in private client state. Immutable job results can be reconstructed after remote
workspace removal. A changing retention selection preserves previously accepted
but now unobserved source paths, rather than treating exclusion as deletion.
Ephemeral job fetch/apply retains its existing per-job lifecycle and uses the same
underlying merge engine.

Remote staging is owner-scoped beneath the workspace's private record, outside
its working tree. Local staging and source bodies live under client change state.
`df` counts both. `gc changes` collects old local transfer attempts, and
`gc changes --on PEER` collects remote ones; checkpoints and pending applications
remain protected. Full source reconstruction and retained source blobs use the
workspace byte limit; deltas and attempt staging use the change byte limit.
Staging reconstructs only the changed base paths. Distinct historical source
bodies count toward the source limit, including pinned creation/checkpoint bodies.
Staging admits at most 4,096 attempts and refuses further growth once retained
attempt bytes exceed the change byte limit; a single in-progress capture can temporarily
use additional bounded base/archive/extraction storage. No pinned source body is
automatically evicted. Busy local transfer relationships are skipped with an
incomplete-inventory diagnostic; dry-run GC counts them as protected. Collection
continues past damaged relationships and reports both partial progress and errors.
Network uploads use unpublished temporary directories outside the workspace gate.
Only one upload per workspace occupies temporary storage; additional uploads
wait cancelably without blocking commands. Inventory includes those temporary
bytes under workspace transfers, even if the workspace is removed mid-upload.
Before staging, the daemon reacquires the gate and rechecks owner and directory
identity; removal and recreation cannot retarget an upload. Startup deletes
unpublished upload directories. Failed upload cleanup stays inventoried and blocks
new uploads to that workspace until startup retries it. GC stops on cancellation,
including while waiting for a workspace gate. Push retries retain the original immutable request after
an uncertain outcome, while completed receipts replay without reapplying files.
