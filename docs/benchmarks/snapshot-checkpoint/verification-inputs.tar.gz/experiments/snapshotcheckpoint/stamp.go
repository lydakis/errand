//go:build darwin || linux

package snapshotcheckpoint

type stamp struct {
	Device, Inode                                  uint64
	Size                                           int64
	Mode                                           uint32
	ModifiedSec, ModifiedNS, ChangedSec, ChangedNS int64
	BornSec, BornNS                                int64
}
