//go:build darwin || linux

package snapshotcheckpoint

import (
	"context"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/lydakis/errand/internal/snapshot"
)

func fixture(t *testing.T) (string, string) {
	t.Helper()
	root, cache := t.TempDir(), t.TempDir()
	for name, body := range map[string]string{".errandignore": "", "a": "before", "b": "stable"} {
		if err := os.WriteFile(filepath.Join(root, name), []byte(body), 0600); err != nil {
			t.Fatal(err)
		}
	}
	return root, cache
}

func oracle(t *testing.T, root, cache string) Result {
	t.Helper()
	ctx := context.Background()
	got, err := Prepare(ctx, root, cache, snapshot.SelectOptions{})
	if err != nil {
		t.Fatal(err)
	}
	want, err := Cold(ctx, root, snapshot.SelectOptions{})
	if err != nil {
		t.Fatal(err)
	}
	a, err := got.State.RootHash(ctx)
	if err != nil {
		t.Fatal(err)
	}
	b, err := want.State.RootHash(ctx)
	if err != nil || a != b {
		t.Fatalf("checkpoint differs from cold snapshot: %s %s %v", a, b, err)
	}
	return got
}

func TestRestartReusesObservationsAndRevalidatesEdits(t *testing.T) {
	root, cache := fixture(t)
	first := oracle(t, root, cache)
	if first.Reused != 0 || !first.Written {
		t.Fatalf("cold: %+v", first)
	}
	warm := oracle(t, root, cache)
	if warm.Reused != 3 || warm.Hashed != 0 || warm.Written {
		t.Fatalf("warm: %+v", warm)
	}
	name := filepath.Join(root, "a")
	info, _ := os.Stat(name)
	time.Sleep(time.Millisecond)
	if err := os.WriteFile(name, []byte("after!"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(name, info.ModTime(), info.ModTime()); err != nil {
		t.Fatal(err)
	}
	changed := oracle(t, root, cache)
	if changed.Hashed != 1 || changed.Reused != 2 {
		t.Fatalf("backdated edit: %+v", changed)
	}
	if err := os.WriteFile(name+".new", []byte("atomic"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.Rename(name+".new", name); err != nil {
		t.Fatal(err)
	}
	oracle(t, root, cache)
	if err := os.Chmod(name, 0700); err != nil {
		t.Fatal(err)
	}
	oracle(t, root, cache)
	if err := os.Remove(name); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir(filepath.Join(root, "nested"), 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink("../b", filepath.Join(root, "nested/link")); err != nil {
		t.Fatal(err)
	}
	oracle(t, root, cache)
}

func TestCacheFailureIdentityAndSelectionFallBack(t *testing.T) {
	root, cache := fixture(t)
	oracle(t, root, cache)
	file := filepath.Join(cache, "checkpoint")
	data, err := os.ReadFile(file)
	if err != nil {
		t.Fatal(err)
	}
	for _, broken := range [][]byte{data[:len(data)/2], append([]byte("bad"), data[3:]...)} {
		if err := os.WriteFile(file, broken, 0600); err != nil {
			t.Fatal(err)
		}
		got := oracle(t, root, cache)
		if got.Reused != 0 || got.CacheStatus != "corrupt" {
			t.Fatalf("corrupt: %+v", got)
		}
	}
	if err := os.WriteFile(filepath.Join(root, ".errandignore"), []byte("b\n"), 0600); err != nil {
		t.Fatal(err)
	}
	got := oracle(t, root, cache)
	if got.Reused != 0 || got.CacheStatus != "identity" {
		t.Fatalf("policy: %+v", got)
	}
	other, _ := fixture(t)
	if got := oracle(t, other, cache); got.Reused != 0 || got.CacheStatus != "identity" {
		t.Fatalf("checkout: %+v", got)
	}
	if err := os.WriteFile(filepath.Join(cache, ".checkpoint.tmp"), []byte("interrupted write"), 0600); err != nil {
		t.Fatal(err)
	}
	oracle(t, root, cache)
	if _, err := os.Stat(filepath.Join(cache, ".checkpoint.tmp")); !os.IsNotExist(err) {
		t.Fatalf("orphan temp: %v", err)
	}
}

func TestCancellationAndCachePlacement(t *testing.T) {
	root, cache := fixture(t)
	oracle(t, root, cache)
	before, _ := os.ReadFile(filepath.Join(cache, "checkpoint"))
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := Prepare(ctx, root, cache, snapshot.SelectOptions{}); err == nil {
		t.Fatal("accepted cancellation")
	}
	after, _ := os.ReadFile(filepath.Join(cache, "checkpoint"))
	if string(before) != string(after) {
		t.Fatal("cancelled preparation replaced checkpoint")
	}
	if _, err := Prepare(context.Background(), root, filepath.Join(root, "cache"), snapshot.SelectOptions{}); err == nil {
		t.Fatal("accepted cache inside source")
	}
}
