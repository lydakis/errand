import json,statistics,sys
from pathlib import Path
report=json.loads(Path(sys.argv[1]).read_text())
summary={}
for case in dict.fromkeys(s['case'] for s in report['samples']):
 row={}
 selected={v:{s['round']:s for s in report['samples'] if s['case']==case and s['variant']==v} for v in ('baseline','candidate')}
 metrics=['ns/op','stage-ms/op','apply-ms/op','client-ms/op','negotiate-ms/op','fetch-ms/op']
 for metric in metrics:
  if not all(metric in s['metrics'] for values in selected.values() for s in values.values()):continue
  pairs=sorted(set(selected['baseline'])&set(selected['candidate']))
  ratios=[selected['candidate'][i]['metrics'][metric]/selected['baseline'][i]['metrics'][metric] for i in pairs if selected['baseline'][i]['metrics'][metric]>0]
  if not ratios:continue
  row[metric]={'medians':{v:statistics.median(s['metrics'][metric] for s in values.values()) for v,values in selected.items()},'pairs':len(ratios),'median_ratio':statistics.median(ratios),'range':[min(ratios),max(ratios)],'faster':sum(r<1 for r in ratios),'ratios':ratios}
 summary[case]=row
print(json.dumps(summary,indent=2))

