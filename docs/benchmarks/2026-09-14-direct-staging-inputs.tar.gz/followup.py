from pathlib import Path
import os,sys,subprocess,time,json,hashlib,platform,re,statistics
root=Path(__file__).resolve().parent
out=root/'followup-results';out.mkdir(exist_ok=False)
fixtures=out/'fixtures';fixtures.mkdir()
env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0',TMPDIR=str(fixtures))
report=dict(reason='Original Cabal controls: ephemeral job slower in 3/3 pairs, structural watch mixed with adverse median. Follow up with 7 alternating pairs and same-baseline-binary controls; preserve original data.',host=platform.platform(),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),variants={},samples=[])
def save(): (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(cmd,cwd,log):
 t=time.monotonic();p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/log).write_text(p.stdout)
 if p.returncode:raise RuntimeError(f'{cmd}: exit {p.returncode}; {log}')
 return p.stdout,time.monotonic()-t
def digest(tree,production=False):
 h=hashlib.sha256()
 for p in sorted([p for p in tree.rglob('*.go') if not production or not p.name.endswith('_test.go')]+[tree/'go.mod',tree/'go.sum']):
  h.update(str(p.relative_to(tree)).encode()+b'\0'+p.read_bytes()+b'\0')
 return h.hexdigest()
def parse(raw):
 matches=[];pending=None
 for line in raw.splitlines():
  head=re.match(r'^(Benchmark\S+)-\d+\s*(.*)$',line)
  if head:pending=head[1];line=head[2]
  m=re.match(r'^\s*(\d+)\s+(.+)$',line)
  if pending and m:
   fields=m[2].split()
   if len(fields)%2 or 'ns/op' not in fields:continue
   matches.append(dict(name=pending,iterations=int(m[1]),metrics={fields[i+1]:float(fields[i]) for i in range(0,len(fields),2)}));pending=None
 if len(matches)!=1:raise RuntimeError(f'expected one benchmark summary: {matches}')
 return matches[0]
expected=json.loads((root/'inputs-manifest.json').read_text())
report['go']=run(['go','version'],root,'go.txt')[0].strip()
report['filesystem']=run(['stat','-f','-c','%T','.'],fixtures,'filesystem.txt')[0].strip()
for name in ('baseline','candidate'):
 tree=root/name;source=digest(tree)
 assert source==expected['variants'][name]['go_source_sha256']
 binary=out/(name+'.test')
 run(['go','test','-c','-o',str(binary),'./cmd/errand'],tree,name+'-build.txt')
 report['variants'][name]=dict(source_sha256=source,production_sha256=digest(tree,True),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
cases=[('ephemeral-job','^BenchmarkWorkspaceCreationAndSubmission$/^ephemeral-job$'),('watch-structural','^BenchmarkWatchWorkloads$/^structural$')]
for n in range(7):
 order=['baseline','candidate'] if n%2==0 else ['candidate','baseline']
 for key,pattern in cases:
  for mode in (['comparison','same-binary'] if n%2==0 else ['same-binary','comparison']):
   for slot in order:
    actual=slot if mode=='comparison' else 'baseline'
    log=f'{n}-{key}-{mode}-{slot}.txt';load=os.getloadavg()
    raw,elapsed=run([str(out/(actual+'.test')),'-test.run=^$',f'-test.bench={pattern}','-test.benchtime=3x','-test.benchmem','-test.timeout=10m'],root/actual,log)
    report['samples'].append(dict(variant=slot,binary_variant=actual,case=key,mode=mode,round=n,log=log,load_before=load,load_after=os.getloadavg(),elapsed=elapsed,**parse(raw)));save()
  print(f'round {n+1}: {key}',flush=True)
assert len(report['samples'])==56
for name in ('baseline','candidate'):assert digest(root/name)==report['variants'][name]['source_sha256']
for p in out.glob('*.test'):p.unlink()
print('COMPLETE',flush=True)
