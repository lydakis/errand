from pathlib import Path
import os, sys, subprocess, time, json, hashlib, platform, re, plistlib
root=Path(__file__).resolve().parent
out=root/'results';out.mkdir(exist_ok=False)
fixtures=out/'fixtures';fixtures.mkdir()
env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0',TMPDIR=str(fixtures))
report=dict(baseline='f85e950',host=platform.platform(),machine=platform.machine(),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),gomaxprocs=2,variants={},samples=[],warmups=[],validation={},orders=[])
def save(): (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(cmd,cwd,log,extra=None):
 t=time.monotonic()
 p=subprocess.run(cmd,cwd=cwd,env=env if extra is None else dict(env,**extra),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/log).write_text(p.stdout)
 if p.returncode: raise RuntimeError(f'{cmd}: exit {p.returncode}; {log}')
 return p.stdout,time.monotonic()-t
def digest(tree,production=False):
 h=hashlib.sha256()
 for p in sorted([p for p in tree.rglob('*.go') if not production or not p.name.endswith('_test.go')]+[tree/'go.mod',tree/'go.sum']):
  h.update(str(p.relative_to(tree)).encode()+b'\0'+p.read_bytes()+b'\0')
 return h.hexdigest()
def parse(raw):
 matches=[];pending=None
 for line in raw.splitlines():
  head=re.match(r'^(Benchmark\S+)-\d+\s*(.*)$',line)
  if head:pending=head[1];line=head[2]
  m=re.match(r'^\s*(\d+)\s+(.+)$',line)
  if pending and m:
   fields=m[2].split()
   if len(fields)%2 or 'ns/op' not in fields:continue
   metrics={fields[i+1]:float(fields[i]) for i in range(0,len(fields),2)}
   matches.append(dict(name=pending,iterations=int(m[1]),metrics=metrics));pending=None
 if len(matches)!=1:raise RuntimeError(f'expected one benchmark summary: {matches}')
 return matches[0]
report['go']=run(['go','version'],root,'go.txt')[0].strip()
if sys.platform=='darwin':
 disk=run(['df','-P','.'],fixtures,'df.txt')[0].splitlines()[-1].split()[0]
 report['filesystem']=plistlib.loads(run(['diskutil','info','-plist',disk],fixtures,'filesystem.txt')[0].encode())['FilesystemType']
else:report['filesystem']=run(['stat','-f','-c','%T','.'],fixtures,'filesystem.txt')[0].strip()
for name in ('baseline','candidate'):
 tree=root/name;(out/name).mkdir()
 report['variants'][name]=dict(source_sha256=digest(tree),production_sha256=digest(tree,True),binaries={})
 checks=[('tests',['go','test','-timeout=10m','./...'],None)]
 if name=='candidate':checks += [('vet',['go','vet','./...'],None),('race',['go','test','-race','-timeout=10m','./internal/changes','./internal/daemon','./internal/client','./cmd/errand'],{'CGO_ENABLED':'1'})]
 for label,cmd,extra in checks:
  _,elapsed=run(cmd,tree,f'{name}/{label}.txt',extra);report['validation'][name+'/'+label]=elapsed;save();print(f'{name}: {label} passed',flush=True)
 for package in ('internal/changes','cmd/errand'):
  binary=out/name/(package.replace('/','-')+'.test')
  run(['go','test','-c','-o',str(binary),'./'+package],tree,f'{name}/build-{package.replace("/","-")}.txt')
  report['variants'][name]['binaries'][package]=hashlib.sha256(binary.read_bytes()).hexdigest()
 save()
def bench(name,key,pattern,duration,number,package='cmd/errand',warmup=False):
 log=f'{name}/{number}-{key}.txt';load=os.getloadavg()
 raw,elapsed=run([str(out/name/(package.replace('/','-')+'.test')),'-test.run=^$',f'-test.bench={pattern}',f'-test.benchtime={duration}','-test.benchmem','-test.timeout=10m'],root/name,log)
 sample=dict(variant=name,case=key,round=number,load_before=load,load_after=os.getloadavg(),elapsed=elapsed,log=log,**parse(raw))
 report['warmups' if warmup else 'samples'].append(sample);save()
primary=[
 ('stage-small','internal/changes','^BenchmarkTransferStageBodies$/^small$','5x'),
 ('stage-batch','internal/changes','^BenchmarkTransferStageBodies$/^batch$','5x'),
 ('stage-large','internal/changes','^BenchmarkTransferStageBodies$/^large$','5x'),
 ('watch','cmd/errand','^BenchmarkWatchPhases$','5x'),
 ('push','cmd/errand','^BenchmarkPushPhases$','3x'),
 ('persistent-fetch','cmd/errand','^BenchmarkFetchCompletion$/^persistent=true$','3x'),
]
controls=[
 ('ephemeral-fetch','cmd/errand','^BenchmarkFetchCompletion$/^persistent=false$','3x'),
 ('workspace-create','cmd/errand','^BenchmarkWorkspaceCreationAndSubmission$/^workspace-create$','3x'),
 ('ephemeral-job','cmd/errand','^BenchmarkWorkspaceCreationAndSubmission$/^ephemeral-job$','3x'),
 ('watch-atomic','cmd/errand','^BenchmarkWatchWorkloads$/^nested-atomic$','3x'),
 ('watch-structural','cmd/errand','^BenchmarkWatchWorkloads$/^structural$','3x'),
]
report['cases']={'primary':primary,'controls':controls};save()
for name in ('baseline','candidate'):bench(name,'watch-warmup','^BenchmarkWatchPhases$','1x',-1,warmup=True)
for n in range(7):
 order=['baseline','candidate'] if n%2==0 else ['candidate','baseline'];report['orders'].append(order)
 for key,package,pattern,duration in primary+(controls if n<3 else []):
  for name in order:bench(name,key,pattern,duration,n,package)
  print(f'round {n+1}: {key}',flush=True)
assert len(report['samples'])==114
for name in ('baseline','candidate'):assert digest(root/name)==report['variants'][name]['source_sha256']
for p in out.rglob('*.test'):p.unlink()
print('COMPLETE',flush=True)

