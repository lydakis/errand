//go:build darwin || linux

package snapshotcheckpoint

import "github.com/lydakis/errand/internal/snapshot"

type stamp = snapshot.ObservationStamp

var fingerprint = snapshot.Fingerprint
