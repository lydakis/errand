# Shared checkpoint builder comparison

## Scope

This slice compares the committed observation checkpoint (`5866129`) with source
observations collected by the ordinary snapshot builder. The checkpoint remains
an experiment. Production callers use the refactored ordinary builder but do not
load or publish disk checkpoints.

The in-memory representation remains the existing adaptive contiguous/Merkle
engine. Neither candidate persists derived tree nodes or changes the wire format.

## Changes under measurement

- Expand selected paths and ancestors once, then collect native observations in
  the same pass that constructs manifest entries and reads changed bodies.
- Reuse matching hashes after fresh native stat checks. Verify changed entries and
  directory identity/mode before publication; the caller still verifies selection.
- Stop collecting observations when the expanded selection exceeds the checkpoint
  entry ceiling. Prepare the ordinary manifest once. If checkpoint identity is
  unavailable, use the already selected paths instead of repeating selection.
- Validate and own loaded metadata through `manifest.New` once. The update variant
  carries that validated snapshot into index construction instead of validating
  and copying the same loaded entries again. Decoder slices remain separate from
  the immutable snapshot; there is no unchecked constructor.
- Compare reconstructing the prior index and applying edits (`shared-update`)
  with constructing the current index directly (`shared-current`). Both produce a
  ready adaptive index and the existing wire root.

The shared builder checks logical byte and entry limits before hashing, including
when reusing hashes. Its directory checks allow ignored sibling timestamp churn
while preserving native identity, type and mode. Cancellation, atomic replacement,
backdated edits, malformed checkpoints and source-selection checks remain covered.
The entry ceiling includes implicit ancestors. The 64 MiB checkpoint byte ceiling
still applies to the encoded payload; it is not a bound on peak allocation.

## Method

Each native campaign interleaves four variants: frozen ordinary cold preparation,
frozen checkpoint preparation, shared-update and shared-current. Each case has
eight rounds. Rotation plus reversal puts each variant in each execution position
twice. Every round checks identical wire roots and expected hash/reuse/write/cache
status counters. A separate eight-pair comparison checks the ordinary builder in
the frozen and candidate binaries.

Fixtures: 1,000 x 32-byte files; 10,000 x 4-KiB files; 1,000 x 64-KiB files;
50,000 x 128-byte files; and a Git-selected 10,000 x 4-KiB fixture. Files are spread
across directories of 100 entries. Explicit-ignore fixtures add an empty
`.errandignore`. Git fixtures have an initialized index and no `.errandignore`.
Cases cover missing checkpoints, unchanged restarts, one-file edits and batches
of 1,000 changed files. Miss means the advisory checkpoint is removed, not that
filesystem caches are cold. No transfer or application-readiness latency is timed.

The same per-host environment, source fixture and candidate binary apply to both
index strategies. The frozen archive and source digest are checked before its
binary is built. Reports include source/harness/binary identities, toolchain,
filesystem/mount metadata, every raw sample and execution position. `Total` is
measured inside Go and includes preparation plus wire hashing. Python process
polling time is not used for performance claims.

The shared pass combines scan and hashing work in `Phases.Hash`; its `Scan` value
is zero. Loaded-state validation moved into `Load`, so compare total time or
`Load + Index` when evaluating that handoff. Per-phase movement alone is not a
speedup, and the combined comparison does not isolate each change's contribution.

## Production gates

Disk checkpoints remain gated on executable filesystem eligibility, controlled
cache ownership/lifetime, mount-alias handling, selection guards through freezing,
and end-to-end measurements across push, both fetch modes, watch restart, workspace
creation and ephemeral submission. Persisted derived-index restoration and
changed-record publication are later measured alternatives. Large-file deltas
remain roadmap step 4.
