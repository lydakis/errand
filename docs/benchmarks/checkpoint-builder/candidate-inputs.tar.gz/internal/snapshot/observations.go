package snapshot

import (
	"context"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"

	"github.com/lydakis/errand/internal/proto"
)

// ObservationStamp is native evidence for advisory hash reuse, not proof of
// current file contents. Callers must bind persisted observations to the
// checkout, boot, filesystem and selection policy, and still verify packed bodies.
type ObservationStamp struct {
	Device, Inode                                  uint64
	Size                                           int64
	Mode                                           uint32
	ModifiedSec, ModifiedNS, ChangedSec, ChangedNS int64
	BornSec, BornNS                                int64
}

type Observation struct {
	Entry proto.ManifestEntry
	Stamp ObservationStamp
}

// ObservedBuild owns a manifest and pending observations from the ordinary
// builder pass. Verify must succeed before observations are persisted. Selection
// verification remains the caller's responsibility, including after freezing.
type ObservedBuild struct {
	Manifest          proto.Manifest
	Observations      []Observation
	Hashed, Reused    int
	Changed, Disabled bool
	prior             []Observation
	cursor            int
	pending           []int
}

// BuildObservedContext accepts sorted, validated, identity-matched advisory
// observations. An entry ceiling bypasses observation collection before hashing
// or scanning, while still building the selected manifest exactly once.
func BuildObservedContext(ctx context.Context, root string, paths []string, prior []Observation, maxBytes int64, maxEntries, observationLimit int) (*ObservedBuild, error) {
	paths = expandPaths(paths)
	r := &ObservedBuild{prior: prior, Changed: len(paths) != len(prior)}
	if observationLimit >= 0 && len(paths) > observationLimit {
		r.Disabled = true
	}
	if !r.Disabled {
		r.Observations = make([]Observation, 0, len(paths))
	}
	m, err := buildSelectedContext(ctx, root, paths, maxBytes, maxEntries, nil, r)
	r.Manifest = m
	r.prior = nil
	return r, err
}

func (r *ObservedBuild) lookup(name string, info fs.FileInfo) (proto.ManifestEntry, bool, error) {
	if r == nil || r.Disabled {
		return proto.ManifestEntry{}, false, nil
	}
	s, err := Fingerprint(info)
	if err != nil {
		return proto.ManifestEntry{}, false, err
	}
	for r.cursor < len(r.prior) && r.prior[r.cursor].Entry.Path < name {
		r.cursor++
	}
	if r.cursor < len(r.prior) {
		old := r.prior[r.cursor]
		if old.Entry.Path == name && old.Stamp == s {
			return old.Entry, true, nil
		}
	}
	return proto.ManifestEntry{}, false, nil
}

func (r *ObservedBuild) record(entry proto.ManifestEntry, info fs.FileInfo, reused bool) error {
	if r == nil {
		return nil
	}
	if entry.Type == proto.EntryFile {
		if reused {
			r.Reused++
		} else {
			r.Hashed++
		}
	}
	if r.Disabled {
		return nil
	}
	s, err := Fingerprint(info)
	if err != nil {
		return err
	}
	if !reused {
		r.Changed = true
	}
	if !reused || entry.Type == proto.EntryDir {
		r.pending = append(r.pending, len(r.Observations))
	}
	r.Observations = append(r.Observations, Observation{entry, s})
	return nil
}

// Verify binds newly read metadata/hashes to their pre-build observations.
// Unchanged regular files need only the fresh stat done by the builder. Ignored
// sibling churn can change directory timestamps without changing its metadata.
func (r *ObservedBuild) Verify(ctx context.Context, root string) error {
	for _, i := range r.pending {
		if err := ctx.Err(); err != nil {
			return err
		}
		e := &r.Observations[i]
		info, err := os.Lstat(filepath.Join(root, filepath.FromSlash(e.Entry.Path)))
		if err != nil {
			return err
		}
		after, err := Fingerprint(info)
		if err != nil {
			return err
		}
		if !matchesPrepared(e.Stamp, after, e.Entry) {
			return fmt.Errorf("source changed while preparing %q", e.Entry.Path)
		}
		if e.Stamp != after {
			r.Changed = true
		}
		e.Stamp = after
	}
	return ctx.Err()
}

func matchesPrepared(before, after ObservationStamp, entry proto.ManifestEntry) bool {
	if entry.Type != proto.EntryDir {
		return before == after
	}
	return fs.FileMode(before.Mode).IsDir() && fs.FileMode(after.Mode).IsDir() &&
		before.Device == after.Device && before.Inode == after.Inode &&
		before.BornSec == after.BornSec && before.BornNS == after.BornNS &&
		before.Mode == after.Mode && entry.Mode == uint32(fs.FileMode(after.Mode).Perm())
}
