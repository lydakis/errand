//go:build darwin || linux

package snapshot

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"testing"
)

func TestObservedBuilderLimitsAndVerification(t *testing.T) {
	ctx := context.Background()
	root := t.TempDir()
	if err := os.Mkdir(filepath.Join(root, "dir"), 0700); err != nil {
		t.Fatal(err)
	}
	file := filepath.Join(root, "dir/a")
	if err := os.WriteFile(file, []byte("before"), 0600); err != nil {
		t.Fatal(err)
	}
	paths := []string{"dir/a"}
	first, err := BuildObservedContext(ctx, root, paths, nil, -1, -1, 2)
	if err != nil {
		t.Fatal(err)
	}
	if err := first.Verify(ctx, root); err != nil {
		t.Fatal(err)
	}
	if len(first.Observations) != 2 || first.Hashed != 1 {
		t.Fatalf("missing ancestor or body: %+v", first)
	}
	warm, err := BuildObservedContext(ctx, root, paths, first.Observations, -1, -1, 2)
	if err != nil || warm.Reused != 1 || warm.Hashed != 0 || warm.Changed {
		t.Fatalf("reuse: %+v %v", warm, err)
	}
	bypass, err := BuildObservedContext(ctx, root, paths, first.Observations, -1, -1, 1)
	if err != nil || !bypass.Disabled || len(bypass.Observations) != 0 || bypass.Hashed != 1 || bypass.Reused != 0 {
		t.Fatalf("bypass: %+v %v", bypass, err)
	}
	if bypass.Manifest.RootHash() != first.Manifest.RootHash() {
		t.Fatal("bypass changed snapshot")
	}
	for _, prior := range [][]Observation{nil, first.Observations} {
		if _, err := BuildObservedContext(ctx, root, paths, prior, 5, -1, 2); !errors.Is(err, ErrByteLimitExceeded) {
			t.Fatalf("byte limit: %v", err)
		}
		if _, err := BuildObservedContext(ctx, root, paths, prior, -1, 1, 2); !errors.Is(err, ErrEntryLimitExceeded) {
			t.Fatalf("entry limit: %v", err)
		}
	}
	if err := os.WriteFile(file, []byte("after!"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := first.Verify(ctx, root); err == nil {
		t.Fatal("accepted changed body")
	}
	cancelled, cancel := context.WithCancel(ctx)
	cancel()
	if _, err := BuildObservedContext(cancelled, root, paths, nil, -1, -1, 2); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}
