//go:build darwin || linux

// Package snapshotcheckpoint is an opt-in experiment, not a production cache.
// Selection and stat work is fresh on every call. Checkpoints contain advisory
// observations, never authorization, destination state or verified file bodies.
package snapshotcheckpoint

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/lydakis/errand/internal/manifest"
	"github.com/lydakis/errand/internal/proto"
	"github.com/lydakis/errand/internal/snapshot"
)

type Phases struct{ Selection, Load, Scan, Hash, Index, Verify, Save time.Duration }
type Result struct {
	State                   *manifest.Snapshot
	Phases                  Phases
	Reused, Hashed          int
	CheckpointBytes         int64
	Written                 bool
	CacheStatus, CacheError string
}

type identity struct {
	Root, OS, Boot, Filesystem string
	Device, Inode              uint64
	Policy                     [32]byte
}
type observation = snapshot.Observation
type checkpoint struct {
	Identity identity
	Entries  []observation
	state    *manifest.Snapshot
}

// Cold uses ordinary selection/build/index without checkpoint observations.
// It deliberately includes PrepareUpdates so both paths return a ready index.
func Cold(ctx context.Context, root string, opts snapshot.SelectOptions) (r Result, err error) {
	start := time.Now()
	if err = ctx.Err(); err != nil {
		return
	}
	paths, _, _, guard, err := snapshot.SelectFilesGuarded(root, opts)
	r.Phases.Selection = time.Since(start)
	if err != nil {
		return r, err
	}
	start = time.Now()
	build := snapshot.BuildBoundedContext
 if os.Getenv("ERRAND_BENCH_LEGACY") == "1" { build = snapshot.BuildLegacyBenchmarkContext }
 m, err := build(ctx, root, paths, -1, -1)
	r.Phases.Hash = time.Since(start)
	if err != nil {
		return r, err
	}
	for _, e := range m.Entries {
		if e.Type == proto.EntryFile {
			r.Hashed++
		}
	}
	start = time.Now()
	r.State, err = manifest.New(ctx, m)
	if err == nil {
		err = r.State.PrepareUpdates(ctx)
	}
	r.Phases.Index = time.Since(start)
	start = time.Now()
	if err == nil {
		err = guard.Verify()
	}
	if err == nil {
		err = ctx.Err()
	}
	r.Phases.Verify = time.Since(start)
	return r, err
}

// Prepare reopens a bounded checkpoint and checks every selected path. Changed
// paths use the existing snapshot builder; updates use the existing adaptive
// manifest engine. Callers must still freeze/verify shipped bodies normally.
func Prepare(ctx context.Context, root, cache string, opts snapshot.SelectOptions) (r Result, err error) {
	return prepare(ctx, root, cache, opts, snapshot.BuildObservedContext, false)
}

// PrepareCurrent compares direct current-state construction against restoring
// prior state and applying edits. Both return the same ready adaptive index.
func PrepareCurrent(ctx context.Context, root, cache string, opts snapshot.SelectOptions) (Result, error) {
	return prepare(ctx, root, cache, opts, snapshot.BuildObservedContext, true)
}

// A per-call builder boundary lets tests schedule real source changes between
// construction and verification without global hooks or timing assumptions.
func prepare(ctx context.Context, root, cache string, opts snapshot.SelectOptions, build func(context.Context, string, []string, []snapshot.Observation, int64, int, int) (*snapshot.ObservedBuild, error), direct bool) (r Result, err error) {
	if err = ctx.Err(); err != nil {
		return
	}
	root, err = filepath.Abs(root)
	if err != nil {
		return
	}
	root, err = filepath.EvalSymlinks(root)
	if err != nil {
		return
	}
	cache, err = filepath.Abs(cache)
	if err != nil {
		return
	}
	// Resolve existing ancestors even when the requested cache does not exist.
	parent := cache
	var missing []string
	for {
		resolved, e := filepath.EvalSymlinks(parent)
		if e == nil {
			cache = filepath.Join(append([]string{resolved}, missing...)...)
			break
		}
		if !os.IsNotExist(e) {
			return r, e
		}
		missing = append([]string{filepath.Base(parent)}, missing...)
		parent = filepath.Dir(parent)
	}
	if rel, e := filepath.Rel(root, cache); e != nil || rel == "." || rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return r, fmt.Errorf("checkpoint directory must be outside source")
	}
	// Lexical paths do not identify case aliases on APFS. Check existing
	// ancestors by native identity before any cache file can enter selection.
	rootInfo, err := os.Stat(root)
	if err != nil {
		return r, err
	}
	for ancestor := cache; ; ancestor = filepath.Dir(ancestor) {
		info, e := os.Stat(ancestor)
		if e != nil && !os.IsNotExist(e) {
			return r, e
		}
		if e == nil && os.SameFile(rootInfo, info) {
			return r, fmt.Errorf("checkpoint directory must be outside source")
		}
		if ancestor == filepath.Dir(ancestor) {
			break
		}
	}
	start := time.Now()
	paths, _, policy, guard, err := snapshot.SelectFilesGuarded(root, opts)
	if err != nil {
		return r, err
	}
	r.Phases.Selection = time.Since(start)
	start = time.Now()
	key, keyErr := checkoutIdentity(root, policy, opts)
	var prior checkpoint
	status := "unsupported"
	var size int64
	if keyErr == nil && len(paths) > maxEntries {
		status = "oversized"
	} else if keyErr == nil {
		prior, status, size, err = readCheckpoint(ctx, cache, key)
	} else {
		r.CacheError = keyErr.Error()
	}
	r.CacheStatus, r.CheckpointBytes = status, size
	r.Phases.Load = time.Since(start)
	if err != nil {
		return r, err
	}
	start = time.Now()
	limit := maxEntries
	if keyErr != nil {
		limit = 0
	}
	built, err := build(ctx, root, paths, prior.Entries, -1, -1, limit)
	if err != nil {
		return r, err
	}
	r.Hashed, r.Reused = built.Hashed, built.Reused
	if err = built.Verify(ctx, root); err != nil {
		return r, err
	}
	next := checkpoint{Identity: key, Entries: built.Observations}
	writable := keyErr == nil && !built.Disabled && (status != "hit" || built.Changed)
	if built.Disabled && keyErr == nil {
		r.CacheStatus = "oversized"
	}
	r.Phases.Hash = time.Since(start)
	start = time.Now()
	if status == "hit" && !direct && !built.Disabled {
		r.State = prior.state
		err = r.State.PrepareUpdates(ctx)
		if err == nil {
			edits := differences(prior.Entries, next.Entries)
			if len(edits) != 0 {
				r.State, err = r.State.Update(ctx, edits)
			}
		}
	} else {
		r.State, err = manifest.New(ctx, built.Manifest)
		if err == nil {
			err = r.State.PrepareUpdates(ctx)
		}
	}
	r.Phases.Index = time.Since(start)
	if err != nil {
		return r, err
	}
	start = time.Now()
	if err = guard.Verify(); err != nil {
		return r, err
	}
	if keyErr == nil {
		now, identityErr := checkoutIdentity(root, policy, opts)
		if identityErr != nil || key != now {
			return r, fmt.Errorf("checkout identity changed during preparation")
		}
	}
	if err = ctx.Err(); err != nil {
		return r, err
	}
	r.Phases.Verify = time.Since(start)
	if writable {
		start = time.Now()
		r.CheckpointBytes, err = writeCheckpoint(ctx, cache, next)
		r.Phases.Save = time.Since(start)
		if err != nil {
			if ctx.Err() != nil {
				return r, ctx.Err()
			}
			r.CacheError, err = err.Error(), nil // Recomputable cache never blocks a valid snapshot.
		} else {
			r.Written = true
		}
	}
	return r, nil
}

func checkoutIdentity(root string, policy proto.SelectionPolicy, opts snapshot.SelectOptions) (identity, error) {
	info, err := os.Lstat(root)
	if err != nil {
		return identity{}, err
	}
	if !info.IsDir() {
		return identity{}, fmt.Errorf("source root is not a directory")
	}
	s, err := snapshot.Fingerprint(info)
	if err != nil {
		return identity{}, err
	}
	boot, err := bootIdentity()
	if err != nil || boot == "" {
		return identity{}, fmt.Errorf("boot identity unavailable: %v", err)
	}
	filesystem, err := filesystemIdentity(root)
	if err != nil {
		return identity{}, err
	}
	data, err := json.Marshal(struct {
		Policy  proto.SelectionPolicy
		Options snapshot.SelectOptions
	}{policy, opts})
	return identity{Root: root, OS: runtime.GOOS, Boot: boot, Filesystem: filesystem, Device: s.Device, Inode: s.Inode, Policy: sha256.Sum256(data)}, err
}

func differences(before, after []observation) []manifest.Edit {
	var edits []manifest.Edit
	i, j := 0, 0
	for i < len(before) || j < len(after) {
		if i < len(before) && (j == len(after) || before[i].Entry.Path < after[j].Entry.Path) {
			edits = append(edits, manifest.Edit{Entry: before[i].Entry, Delete: true})
			i++
		} else if j < len(after) && (i == len(before) || after[j].Entry.Path < before[i].Entry.Path) {
			edits = append(edits, manifest.Edit{Entry: after[j].Entry})
			j++
		} else {
			if before[i].Entry != after[j].Entry {
				edits = append(edits, manifest.Edit{Entry: after[j].Entry})
			}
			i++
			j++
		}
	}
	return edits
}
