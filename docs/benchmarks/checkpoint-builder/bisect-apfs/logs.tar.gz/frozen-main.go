//go:build darwin || linux

package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"os/signal"
"runtime"
	"syscall"
	"time"

	checkpoint "github.com/lydakis/errand/experiments/snapshotcheckpoint"
	"github.com/lydakis/errand/internal/snapshot"
)

func main() {
	root, cache, mode := flag.String("root", "", "fixture root"), flag.String("cache", "", "private cache directory"), flag.String("mode", "cold", "cold or checkpoint")
	flag.Parse()
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	var before, after runtime.MemStats
 runtime.ReadMemStats(&before)
 start := time.Now()
	var result checkpoint.Result
	var err error
	switch *mode {
	case "cold":
		result, err = checkpoint.Cold(ctx, *root, snapshot.SelectOptions{})
	case "checkpoint":
		result, err = checkpoint.Prepare(ctx, *root, *cache, snapshot.SelectOptions{})
	default:
		err = fmt.Errorf("unknown mode %q", *mode)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	wireStart := time.Now()
	hash, err := result.State.RootHash(ctx)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	runtime.ReadMemStats(&after)
result.State = nil
	if err := json.NewEncoder(os.Stdout).Encode(struct {
		Result      checkpoint.Result
		Hash        string
		Wire, Total time.Duration
AllocBytes, Mallocs, NumGC uint64
	}{result, hash, time.Since(wireStart), time.Since(start), after.TotalAlloc-before.TotalAlloc, after.Mallocs-before.Mallocs, uint64(after.NumGC-before.NumGC)}); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
