from pathlib import Path
import os, runpy, sys
root = Path(__file__).resolve().parent
os.chdir(root/'candidate')
sys.path.insert(0,str(root/'candidate/scripts'))
sys.argv=['benchmark_snapshot_integration.py','--baseline',str(root/'baseline'),'--output',str(root/'results'),'--revision','f109142 shared initialization','--scope','initialization','--rounds','5']
sys.argv += ['--allow-input-difference', 'internal/changes/base_test.go']
sys.argv += ['--allow-input-difference', 'internal/changes/base_shared_test.go']
sys.argv += ['--allow-input-difference', 'internal/changes/staging_parallel_test.go']
sys.argv += ['--allow-input-difference', 'internal/changes/transfer_materialize_test.go']
runpy.run_path('scripts/benchmark_snapshot_integration.py',run_name='__main__')
