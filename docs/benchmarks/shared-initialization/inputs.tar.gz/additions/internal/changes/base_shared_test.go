package changes

import (
	"context"
	"io"
	"os"
	"path/filepath"
	"testing"

	"github.com/lydakis/errand/internal/proto"
	"github.com/lydakis/errand/internal/snapshot"
)

func TestCaptureBaseRejectsCorruptionBeforeSync(t *testing.T) {
	source, job := t.TempDir(), t.TempDir()
	file := filepath.Join(source, "file")
	if err := os.WriteFile(file, []byte("good"), 0600); err != nil {
		t.Fatal(err)
	}
	m, err := snapshot.Build(source, []string{"file"})
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(file, []byte("evil"), 0600); err != nil {
		t.Fatal(err)
	}
	err = captureWorkspaceBaseContext(t.Context(), source, job, m,
		func(*os.File) error { t.Error("synced corrupt captured content"); return nil },
		func(string) error { t.Error("published corrupt captured content"); return nil })
	if err == nil {
		t.Fatal("accepted same-size corruption")
	}
	entries, err := os.ReadDir(job)
	if err != nil || len(entries) != 0 {
		t.Fatalf("partial capture: %v, %v", entries, err)
	}
}

func TestCaptureBasePreservesReadOnlySource(t *testing.T) {
	source, job := t.TempDir(), t.TempDir()
	file := filepath.Join(source, "file")
	if err := os.WriteFile(file, []byte("body"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(file, 0400); err != nil {
		t.Fatal(err)
	}
	m, err := snapshot.Build(source, []string{"file"})
	if err != nil {
		t.Fatal(err)
	}
	if err := CaptureWorkspaceBaseContext(t.Context(), source, job, m); err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(file)
	if err != nil || info.Mode().Perm() != 0400 {
		t.Fatalf("source mode changed: %v, %v", info, err)
	}
	if err := snapshot.PackContext(context.Background(), io.Discard, workspaceBasePath(job), m); err != nil {
		t.Fatal(err)
	}
}

func TestCaptureCopyFallbackPreservesIndependentBody(t *testing.T) {
	source, dest := t.TempDir(), t.TempDir()
	file := filepath.Join(source, "file")
	if err := os.WriteFile(file, []byte("body"), 0600); err != nil {
		t.Fatal(err)
	}
	m, err := snapshot.Build(source, []string{"file"})
	if err != nil {
		t.Fatal(err)
	}
	tree, err := os.OpenRoot(dest)
	if err != nil {
		t.Fatal(err)
	}
	defer tree.Close()
	policy := durableMaterialization(func() error { return nil })
	policy.cloneFiles = true
	// A reader without clone support takes the fallback used on non-CoW filesystems.
	err = materializeTransferTree(t.Context(), tree, m, policy, func(e proto.ManifestEntry) (io.ReadCloser, error) {
		f, err := os.Open(file)
		if err != nil {
			return nil, err
		}
		return struct{ io.ReadCloser }{f}, nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(file, []byte("edit"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := snapshot.PackContext(t.Context(), io.Discard, dest, m); err != nil {
		t.Fatal(err)
	}
}
