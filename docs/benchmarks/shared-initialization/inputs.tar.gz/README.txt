Frozen initialization comparison inputs against commit f109142.
Create baseline/ and candidate/ from git archive f109142.
Apply candidate.patch to candidate/.
Copy additions/ contents into candidate/, preserving relative paths.
Overlay base_benchmark_test.go onto internal/changes/base_benchmark_test.go
in baseline/. The candidate patch already includes the identical benchmark.
Place run.py next to baseline/ and candidate/, then run python3 run.py.
The driver validates both trees and runs five alternating pairs on the native
filesystem under results/. All test-input exceptions are explicit in run.py;
benchmark sources and benchmark helper functions match.
The candidate patch and additions are the source freeze actually submitted.
Documentation written afterward is not included in the measured Go identities.
