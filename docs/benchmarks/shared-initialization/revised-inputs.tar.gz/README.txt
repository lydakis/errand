Reconstruct the revised comparison from independent git archives of f109142.
Apply candidate.patch in the candidate tree, then copy additions/ into it.
Overlay base_benchmark_test.go at internal/changes/base_benchmark_test.go in both trees.
Put run.py beside baseline/ and candidate/, then run python3 run.py there.
Use a new root/results directory. The driver validates both trees before timing.
The six exact test-source exceptions are recorded by run.py and report.json.
Results must be on the filesystem being measured; do not put Btrfs fixtures in tmpfs.
