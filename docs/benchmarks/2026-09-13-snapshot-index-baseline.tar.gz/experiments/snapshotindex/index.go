// Package snapshotindex compares immutable metadata representations. It is an
// experiment, not a production snapshot API. Inputs are already validated,
// canonical manifests; selection policy and filesystem evidence live outside it.
package snapshotindex

import (
	"crypto/sha256"
	"encoding/json"
	"sort"

	"github.com/lydakis/errand/internal/proto"
)

// Edit replaces one exact path, or removes it when Delete is true. Removing a
// directory requires explicit edits for its descendants, as produced by Diff.
// Inputs contain unique paths. Entry.Path is also the key for deletions.
type Edit struct {
	Entry  proto.ManifestEntry
	Delete bool
}

// Index owns its metadata. Update and Manifest must not alias caller slices.
// Diff returns sorted edits that transform the receiver into next. Implementations
// only compare their own type. Digest is representation-specific, deterministic
// for the same entries, and is NOT the current protocol's Manifest.RootHash.
type Index interface {
	Update([]Edit) Index
	Diff(next Index) []Edit
	Manifest() proto.Manifest
	Digest() [32]byte
}

func entryDigest(entry proto.ManifestEntry) [32]byte {
	data, err := json.Marshal(entry)
	if err != nil {
		panic(err)
	}
	return sha256.Sum256(data)
}

// diffEntries is the flat, ordered reference implementation.
func diffEntries(before, after []proto.ManifestEntry) []Edit {
	var edits []Edit
	i, j := 0, 0
	for i < len(before) || j < len(after) {
		switch {
		case j == len(after) || i < len(before) && before[i].Path < after[j].Path:
			edits = append(edits, Edit{Entry: before[i], Delete: true})
			i++
		case i == len(before) || after[j].Path < before[i].Path:
			edits = append(edits, Edit{Entry: after[j]})
			j++
		default:
			if before[i] != after[j] {
				edits = append(edits, Edit{Entry: after[j]})
			}
			i++
			j++
		}
	}
	return edits
}

func sortedEdits(edits []Edit) []Edit {
	result := append([]Edit(nil), edits...)
	sort.Slice(result, func(i, j int) bool { return result[i].Entry.Path < result[j].Entry.Path })
	return result
}
