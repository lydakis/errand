package snapshotindex

import (
	"bytes"
	"crypto/sha256"

	"github.com/lydakis/errand/internal/proto"
)

// tree is a deterministic Cartesian tree: path orders entries, SHA256(path)
// orders priorities. Updates copy the search path and share unchanged subtrees.
// Cryptographic priorities avoid systematic imbalance for sorted input, but are
// not a worst-case height guarantee. This prototype is not a hostile-input API.
type tree struct{ root *node }
type node struct {
	entry       proto.ManifestEntry
	priority    [32]byte
	content     [32]byte
	digest      [32]byte
	left, right *node
	count       int
}

func NewTree(entries []proto.ManifestEntry) Index {
	// Sorted entries form a Cartesian tree in O(N), then one hash pass.
	var stack []*node
	for _, entry := range entries {
		n := &node{entry: entry, priority: sha256.Sum256([]byte(entry.Path)), content: entryDigest(entry)}
		for len(stack) > 0 && higher(n, stack[len(stack)-1]) {
			n.left = stack[len(stack)-1]
			stack = stack[:len(stack)-1]
		}
		if len(stack) > 0 {
			stack[len(stack)-1].right = n
		}
		stack = append(stack, n)
	}
	if len(stack) == 0 {
		return &tree{}
	}
	root := stack[0]
	var finish func(*node)
	finish = func(n *node) {
		if n != nil {
			finish(n.left)
			finish(n.right)
			n.rehash()
		}
	}
	finish(root)
	return &tree{root: root}
}

func higher(a, b *node) bool {
	c := bytes.Compare(a.priority[:], b.priority[:])
	return c < 0 || c == 0 && a.entry.Path < b.entry.Path
}
func nodeDigest(n *node) [32]byte {
	if n == nil {
		return [32]byte{}
	}
	return n.digest
}
func (n *node) rehash() {
	n.count = 1
	if n.left != nil {
		n.count += n.left.count
	}
	if n.right != nil {
		n.count += n.right.count
	}
	var data [96]byte
	l, r := nodeDigest(n.left), nodeDigest(n.right)
	copy(data[:32], l[:])
	copy(data[32:64], n.content[:])
	copy(data[64:], r[:])
	n.digest = sha256.Sum256(data[:])
}

func (t *tree) Update(edits []Edit) Index {
	root := t.root
	for _, edit := range edits {
		root = updateNode(root, edit)
	}
	return &tree{root: root}
}
func updateNode(n *node, edit Edit) *node {
	if n == nil {
		if edit.Delete {
			return nil
		}
		n = &node{entry: edit.Entry, priority: sha256.Sum256([]byte(edit.Entry.Path)), content: entryDigest(edit.Entry)}
		n.rehash()
		return n
	}
	if edit.Entry.Path == n.entry.Path {
		if edit.Delete {
			return joinNodes(n.left, n.right)
		}
		if edit.Entry == n.entry {
			return n
		}
		result := *n
		result.entry, result.content = edit.Entry, entryDigest(edit.Entry)
		result.rehash()
		return &result
	}
	result := *n
	if edit.Entry.Path < n.entry.Path {
		result.left = updateNode(n.left, edit)
		if result.left == n.left {
			return n
		}
		if result.left != nil && higher(result.left, &result) {
			top := *result.left
			result.left = top.right
			result.rehash()
			top.right = &result
			top.rehash()
			return &top
		}
	} else {
		result.right = updateNode(n.right, edit)
		if result.right == n.right {
			return n
		}
		if result.right != nil && higher(result.right, &result) {
			top := *result.right
			result.right = top.left
			result.rehash()
			top.left = &result
			top.rehash()
			return &top
		}
	}
	result.rehash()
	return &result
}
func joinNodes(a, b *node) *node {
	if a == nil {
		return b
	}
	if b == nil {
		return a
	}
	if higher(a, b) {
		n := *a
		n.right = joinNodes(a.right, b)
		n.rehash()
		return &n
	}
	n := *b
	n.left = joinNodes(a, b.left)
	n.rehash()
	return &n
}

func (t *tree) Diff(next Index) []Edit {
	var result []Edit
	diffNodes(t.root, next.(*tree).root, &result)
	return result
}
func diffNodes(a, b *node, result *[]Edit) {
	if a == b || nodeDigest(a) == nodeDigest(b) {
		return
	}
	if a == nil || b == nil || a.entry.Path != b.entry.Path {
		// Structural edits can change the Cartesian root. Fall back to a sorted
		// comparison for this subtree. Benchmarks include insertions and deletion
		// of a high-priority root so this cost remains visible.
		*result = append(*result, diffEntries(nodeEntries(a), nodeEntries(b))...)
		return
	}
	diffNodes(a.left, b.left, result)
	if a.entry != b.entry {
		*result = append(*result, Edit{Entry: b.entry})
	}
	diffNodes(a.right, b.right, result)
}
func appendNodes(entries []proto.ManifestEntry, n *node) []proto.ManifestEntry {
	if n == nil {
		return entries
	}
	entries = appendNodes(entries, n.left)
	entries = append(entries, n.entry)
	return appendNodes(entries, n.right)
}
func nodeEntries(n *node) []proto.ManifestEntry {
	if n == nil {
		return nil
	}
	return appendNodes(make([]proto.ManifestEntry, 0, n.count), n)
}
func (t *tree) Manifest() proto.Manifest { return proto.Manifest{Entries: nodeEntries(t.root)} }
func (t *tree) Digest() [32]byte         { return nodeDigest(t.root) }
