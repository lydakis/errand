import os, pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
subprocess.run([sys.executable, "scripts/benchmark_snapshot_integration.py", "--baseline", str(root/"baseline"), "--output", str(root/"results"), "--revision", "checkpoint-reuse-19faf4c", "--rounds", "7", "--scope", "receiver"], cwd=root/"candidate", check=True)
