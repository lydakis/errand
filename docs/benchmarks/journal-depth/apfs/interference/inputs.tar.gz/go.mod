module github.com/lydakis/errand

go 1.27.0

require (
	github.com/BurntSushi/toml v1.6.0
	github.com/fsnotify/fsnotify v1.9.0
	golang.org/x/sys v0.48.0
)
