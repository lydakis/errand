package main

import (
	"cmp"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"text/tabwriter"

	"github.com/lydakis/errand/internal/client"
	"github.com/lydakis/errand/internal/config"
	"github.com/lydakis/errand/internal/pathpolicy"
	"github.com/lydakis/errand/internal/proto"
	"github.com/lydakis/errand/internal/workspace"
)

// Both submission and inspection use these flags and the same resolver.
type runConfigFlags struct {
	caches                        stringList
	noCaches                      bool
	artifacts                     stringList
	noArtifacts                   bool
	session                       sessionFlags
	envs, passenvs                stringList
	envFiles                      stringList
	noEnvFiles                    bool
	profile                       string
	workspace                     string
	on, url, where, workdir, root string
	apply, noApply, noSnapshot    bool
}

func (f *runConfigFlags) bind(fs *flag.FlagSet) {
	f.session.bind(fs)
	fs.Var(&f.caches, "cache", "reuse a runner cache NAME=PATH at a workspace-relative directory (repeatable; replaces configured list)")
	fs.BoolVar(&f.noCaches, "no-caches", false, "disable configured named caches")
	fs.Var(&f.artifacts, "artifact", "retain an exact workspace-relative file or directory, including ignored outputs (repeatable; replaces configured list)")
	fs.BoolVar(&f.noArtifacts, "no-artifacts", false, "disable configured artifact declarations")
	fs.Var(&f.envs, "env", "set NAME=VALUE in the job environment (repeatable; values hidden in diagnostics)")
	fs.Var(&f.envs, "e", "set NAME=VALUE in the job environment (repeatable)")
	fs.Var(&f.passenvs, "passenv", "require and forward a local environment variable (repeatable; replaces configured pass list)")
	fs.Var(&f.envFiles, "env-file", "load a local environment file (repeatable; replaces configured file list)")
	fs.BoolVar(&f.noEnvFiles, "no-env-files", false, "clear configured environment files")
	fs.StringVar(&f.profile, "profile", "", "named run preferences from workspace or personal configuration")
	fs.StringVar(&f.workspace, "workspace", "", "use an existing persistent workspace; overrides the selected profile and never uploads local edits")
	fs.StringVar(&f.where, "where", "", "select a configured runner matching facts, e.g. os=linux,go or *")
	fs.StringVar(&f.on, "on", "", "peer name from personal configuration, or local")
	fs.StringVar(&f.url, "url", "", "peer base URL (mutually exclusive with --on and --where)")
	fs.StringVar(&f.workdir, "workdir", "", "working directory, relative to the workspace root")
	fs.StringVar(&f.workdir, "w", "", "working directory, relative to the workspace root")
	fs.StringVar(&f.root, "workspace-root", "", "snapshot root containing the current directory")
	fs.BoolVar(&f.apply, "apply", false, "apply retained workspace changes after successful completion")
	fs.BoolVar(&f.noApply, "no-apply", false, "do not apply retained workspace changes after the run")
	fs.BoolVar(&f.noSnapshot, "no-snapshot", false, "run in an empty job workspace")
}

func (f runConfigFlags) overrides(fs *flag.FlagSet) (config.RunOverrides, error) {
	set := map[string]bool{}
	fs.Visit(func(f *flag.Flag) { set[f.Name] = true })
	result := config.RunOverrides{Peer: f.on, URL: f.url, Where: f.where, WorkspaceRoot: f.root, NoSnapshot: f.noSnapshot}
	if set["artifact"] && set["no-artifacts"] {
		return result, fmt.Errorf("--artifact and --no-artifacts are mutually exclusive")
	}
	if set["cache"] && set["no-caches"] {
		return result, fmt.Errorf("--cache and --no-caches are mutually exclusive")
	}
	if set["cache"] || f.noCaches {
		result.Caches = []proto.CacheBinding{}
	}
	for _, binding := range f.caches {
		name, path, ok := strings.Cut(binding, "=")
		if !ok {
			return result, fmt.Errorf("--cache requires NAME=PATH")
		}
		result.Caches = append(result.Caches, proto.CacheBinding{Name: name, Path: path})
	}
	if err := pathpolicy.ValidateCaches(result.Caches); err != nil {
		return result, err
	}
	result.Artifacts = f.artifacts
	if f.noArtifacts {
		result.Artifacts = []string{}
	}
	if err := pathpolicy.ValidateArtifacts(result.Artifacts); err != nil {
		return result, err
	}
	var err error
	result.Forwards, err = f.session.overrides(fs)
	if err != nil {
		return result, err
	}
	result.Environment.Pass = f.passenvs
	if set["env-file"] && set["no-env-files"] {
		return result, fmt.Errorf("--env-file and --no-env-files are mutually exclusive")
	}
	result.Environment.Files = f.envFiles
	if f.noEnvFiles {
		result.Environment.Files = []string{}
	}
	for _, path := range result.Environment.Files {
		if path == "" || strings.ContainsRune(path, 0) {
			return result, fmt.Errorf("--env-file requires a nonempty path without NUL")
		}
	}
	for _, name := range f.passenvs {
		if err := workspace.ValidateEnvironmentName(name); err != nil {
			return result, err
		}
	}
	result.Environment.Set = map[string]string{}
	for _, assignment := range f.envs {
		name, value, ok := strings.Cut(assignment, "=")
		if !ok {
			return result, fmt.Errorf("--env requires NAME=VALUE")
		}
		if err := workspace.ValidateEnvironmentName(name); err != nil {
			return result, err
		}
		if strings.ContainsRune(value, 0) {
			return result, fmt.Errorf("--env value for %q contains NUL", name)
		}
		result.Environment.Set[name] = value
	}
	result.Profile = f.profile
	if set["workspace"] {
		if err := proto.ValidateWorkspaceName(f.workspace); err != nil {
			return result, fmt.Errorf("--workspace: %w", err)
		}
		result.Workspace = &f.workspace
	}
	if set["profile"] && f.profile == "" {
		return result, fmt.Errorf("--profile requires a non-empty name")
	}
	if set["where"] && f.where == "" {
		return result, fmt.Errorf("--where requires a non-empty selector")
	}
	if f.where != "" && (f.on != "" || f.url != "") {
		return result, fmt.Errorf("--where cannot be combined with --on or --url")
	}
	if set["on"] && f.on == "" || set["url"] && f.url == "" {
		return result, fmt.Errorf("--on and --url require non-empty values")
	}
	if f.on != "" && f.url != "" {
		return result, fmt.Errorf("--on and --url are mutually exclusive")
	}
	if set["apply"] && set["no-apply"] {
		return result, fmt.Errorf("--apply and --no-apply are mutually exclusive")
	}
	if set["apply"] {
		result.ApplyOnSuccess = &f.apply
	}
	if set["no-apply"] {
		value := !f.noApply
		result.ApplyOnSuccess = &value
	}
	if set["workdir"] || set["w"] {
		result.Workdir = &f.workdir
	}
	if f.noSnapshot && f.root != "" {
		return result, fmt.Errorf("--workspace-root and --no-snapshot are mutually exclusive")
	}
	if f.noSnapshot && f.workdir != "" && f.workdir != "." {
		return result, fmt.Errorf("--workdir must be the workspace root when using --no-snapshot")
	}
	return result, nil
}

func cmdConfig(args []string) int { return cmdConfigTo(args, os.Stdout, os.Stderr) }

// Describe the local source directory without implying it is the runner's path.
func displaySourceWorkdir(effective config.EffectiveRun) string {
	if effective.NoSnapshot {
		return "empty workspace root"
	}
	return filepath.Join(effective.Root, effective.Workdir)
}

func cmdConfigTo(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("errand config", flag.ContinueOnError)
	fs.SetOutput(stderr)
	var flags runConfigFlags
	flags.bind(fs)
	asJSON := fs.Bool("json", false, "print effective run configuration and sources as JSON")
	setFlagUsage(fs, "errand config [options]")
	if err := fs.Parse(args); err != nil {
		if err == flag.ErrHelp {
			return 0
		}
		return 2
	}
	if fs.NArg() != 0 {
		fmt.Fprintf(stderr, "errand: unexpected config arguments: %s\n", strings.Join(fs.Args(), " "))
		return 2
	}
	overrides, err := flags.overrides(fs)
	if err != nil {
		fmt.Fprintf(stderr, "errand: %v\n", err)
		return 2
	}
	cwd, err := os.Getwd()
	if err != nil {
		fmt.Fprintf(stderr, "errand: %v\n", err)
		return client.ExitTransaction
	}
	effective, err := config.ResolveRun(cwd, overrides)
	if err != nil {
		fmt.Fprintf(stderr, "errand: %v\n", err)
		return client.ExitTransaction
	}
	if err := effective.PrepareExecution(false); err != nil {
		fmt.Fprintln(stderr, "errand:", err)
		return 2
	}
	if *asJSON {
		encoder := json.NewEncoder(stdout)
		encoder.SetIndent("", "  ")
		err = encoder.Encode(effective)
	} else {
		w := tabwriter.NewWriter(stdout, 0, 4, 2, ' ', 0)
		fmt.Fprintln(w, "SETTING\tVALUE\tSOURCE")
		for _, row := range []struct {
			key   string
			value any
		}{
			{"profile", effective.Profile},
			{"workspace", effective.Workspace},
			{"where", effective.Where}, {"peer", effective.Peer}, {"url", effective.URL},
			{"remote_command", effective.RemoteCommand}, {"remote_socket", effective.RemoteSocket},
			{"workspace_root", effective.Root}, {"workdir", displaySourceWorkdir(effective)},
			{"project", effective.Project}, {"apply_on_success", effective.ApplyOnSuccess},
			{"no_snapshot", effective.NoSnapshot},
			{"forward", effective.Forwards},
			{"artifacts", effective.Artifacts},
			{"caches", fmt.Sprintf("%d bindings", len(effective.Caches))},
		} {
			if _, exists := effective.Sources[row.key]; !exists {
				continue
			}
			if effective.Workspace != "" && (row.key == "caches" && !effective.CachesOverride || row.key == "artifacts" && !effective.ArtifactsOverride) {
				row.value = "inherited (resolved on runner)"
			}
			fmt.Fprintf(w, "%s\t%s\t%s\n", row.key, terminalSafeField(fmt.Sprint(row.value)), terminalSafeField(effective.Sources[row.key]))
		}
		cacheRows := slices.Clone(effective.Caches)
		slices.SortFunc(cacheRows, func(a, b proto.CacheBinding) int {
			if order := cmp.Compare(effective.CacheSources[a.Name], effective.CacheSources[b.Name]); order != 0 {
				return order
			}
			return cmp.Compare(a.Path, b.Path)
		})
		for _, cache := range cacheRows {
			source := effective.CacheSources[cache.Name]
			if source == "" {
				source = effective.Sources["caches"]
			}
			fmt.Fprintf(w, "%s\t%s\t%s\n", terminalSafeField("cache."+cache.Name), terminalSafeField(cache.Path), terminalSafeField(source))
		}
		for _, entry := range effective.Environment {
			state := entry.Kind + " (value hidden)"
			if entry.Kind == "passenv" {
				state = "passenv (available)"
				if !entry.Available {
					state = "passenv (missing)"
				}
			}
			fmt.Fprintf(w, "%s\t%s\t%s\n", terminalSafeField("env."+entry.Name), state, terminalSafeField(entry.Source))
		}
		err = w.Flush()
	}
	if err != nil {
		fmt.Fprintf(stderr, "errand: writing config: %v\n", err)
		return client.ExitTransaction
	}
	return 0
}
