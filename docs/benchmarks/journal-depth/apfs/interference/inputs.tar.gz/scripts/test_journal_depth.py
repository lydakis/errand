import collections
import unittest

from journal_depth_cases import VARIANTS, fixed_cases, check_receipt, cycle_receipt
from benchmark_snapshot_integration import benchmark_order


class JournalDepthContracts(unittest.TestCase):
    def test_depth_and_workload_each_receive_every_execution_order(self):
        orders = collections.defaultdict(set)
        depth_orders = set()
        for number in range(6):
            depth_orders.add(tuple(d for d,w in fixed_cases(number) if w == 'unchanged'))
            for depth, workload in fixed_cases(number):
                orders[depth, workload].add(tuple(benchmark_order(VARIANTS, number)))
        self.assertEqual(set(orders), {(d,w) for d in (0,8,31) for w in ('unchanged','edit','batch')})
        self.assertTrue(all(len(v)==6 for v in orders.values()))
        self.assertEqual(len(depth_orders),6)

    def test_fixed_history_rejects_fallback_wrong_depth_and_wrong_hash_work(self):
        result = dict(CacheStatus='hit', CacheError='', Written=True, Hashed=1, Reused=99,
                      JournalRecordsLoaded=31, ReplacedBase=False, CheckpointBytes=1000)
        check_receipt({'Result':result}, 100, 1, 'observation-journal', 31, False)
        for field,value in [('CacheStatus','missing'),('CacheError','busy'),('Written',False),
                            ('Hashed',100),('JournalRecordsLoaded',30),('ReplacedBase',True)]:
            with self.subTest(field=field),self.assertRaises(RuntimeError):
                check_receipt({'Result':dict(result,**{field:value})},100,1,'observation-journal',31,False)
        check_receipt({'Result':dict(result,JournalRecordsLoaded=0,ReplacedBase=True)},
                      100,1,'observation-replacement',0,True)

    def test_cycle_includes_all_appends_and_the_terminal_compaction(self):
        samples=[]
        for step in range(33):
            samples.append(dict(Total=10, Wire=1, cache_bytes=100,
                                Result=dict(Phases={'Load':2},CheckpointBytes=100 if step==32 else 1,
                                            Written=True,ReplacedBase=step==32,JournalRecordsLoaded=step)))
        total=cycle_receipt(samples,'observation-journal')
        self.assertEqual(total['Total'],330)
        self.assertEqual(total['Result']['CheckpointBytes'],132)
        for invalid in (samples[:-1],samples+[samples[-1]],samples[:10]+samples[11:]+[samples[10]]):
            with self.assertRaises(RuntimeError):
                cycle_receipt(invalid,'observation-journal')


if __name__=='__main__':
    unittest.main()
