import hashlib,json,os,pathlib,sys,time
root=pathlib.Path.cwd(); sys.path.insert(0,str(root/'candidate/scripts'))
from benchmark_snapshot_integration import benchmark_scratch,run,source_digest,parse_sample,filesystem
from profile_transfer_latency import phase_events
out=root/'results'; out.mkdir(); report={'baseline_revision':'f64148c','rounds':5,'versions':{},'samples':[],'scope':'Native-host loopback diagnostic screen; identical instrumentation; full fetch includes 3 operations after Go calibration, push 1 operation'}
env=dict(os.environ,GOMAXPROCS='2',CGO_ENABLED='0')
try:
 with benchmark_scratch(out) as scratch:
  fixtures=scratch/'fixtures'; fixtures.mkdir(); env['TMPDIR']=str(fixtures)
  report['filesystem']=filesystem(fixtures,env,out,'filesystem')
  report['go']=run(['go','version'],root,env,out/'go.txt')
  report['mount']=run(['mount'] if sys.platform=='darwin' else ['findmnt','-T',str(fixtures),'-n','-o','FSTYPE,OPTIONS'],root,env,out/'mount.txt')
  for variant in ('baseline','candidate'):
   source=root/variant
   report['versions'][variant]={'source_sha256':source_digest(source),'production_sha256':source_digest(source,production=True),'benchmark_sha256':source_digest(source,benchmarks=True)}
   run(['go','test','-c','-o',str(scratch/(variant+'.test')),'./cmd/errand'],source,env,out/(variant+'-build.txt'))
   report['versions'][variant]['binary_sha256']=hashlib.sha256((scratch/(variant+'.test')).read_bytes()).hexdigest()
  assert report['versions']['baseline']['benchmark_sha256']==report['versions']['candidate']['benchmark_sha256']
  print('Both variants compiled with identical benchmark sources',flush=True)
  for label,command in [('tests',['go','test','-timeout=10m','./...']),('vet',['go','vet','./...']),('race',['go','test','-race','-timeout=10m','./internal/changes','./internal/client','./internal/daemon','./cmd/errand'])]:
   run(command,root/'candidate',dict(env,CGO_ENABLED='1') if label=='race' else env,out/(label+'.txt'))
   print(label+' passed',flush=True)
  cases=[('fetch-large','^BenchmarkFetchBodies$/^large$','3x'),('push','^BenchmarkPushPhases$','1x')]
  for number in range(5):
   for case,pattern,iterations in cases:
    for variant in (('baseline','candidate') if number%2==0 else ('candidate','baseline')):
     report['active']={'round':number,'case':case,'variant':variant}
     log=out/f'{number}-{case}-{variant}.txt'; started=time.monotonic(); load=os.getloadavg()
     raw=run([str(scratch/(variant+'.test')),'-test.run=^$',f'-test.bench={pattern}',f'-test.benchtime={iterations}'],root/variant,env,log,timeout=180)
     row={'round':number,'case':case,'variant':variant,'elapsed':time.monotonic()-started,'load_before':load,'load_after':os.getloadavg(),'sample':parse_sample(raw,number),'phases':phase_events(raw)}
     report['samples'].append(row); report.pop('active'); (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'Pair {number+1}/5 {case} completed',flush=True)
  for variant in ('baseline','candidate'): assert source_digest(root/variant)==report['versions'][variant]['source_sha256']
  report['source_stable']=True
 report['status']='complete'
except BaseException as exc:
 report.update(status='failed',error=str(exc)); raise
finally:
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
