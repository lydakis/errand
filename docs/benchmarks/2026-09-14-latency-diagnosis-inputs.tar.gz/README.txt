Frozen inputs for latency diagnosis. Base revision: f64148ca0aa145d50e68b87a84b8e3b2ff863a1b

Create baseline/ and candidate/ from git archive of that revision, then apply
these variant overlays. Run python3 compare.py from their parent directory on
the native host. Requires Go, Python 3 and platform filesystem inspection tools.
The driver runs full candidate tests, vet, race checks, and five alternating
pairs. It removes generated binaries/fixtures and preserves results/.

First APFS diagnostic used baseline Go instrumentation with the helper named
benchmark_phases_test.go (renamed to phases_benchmark_test.go in the comparison).
Use candidate/scripts/profile_transfer_latency.py and its adjacent harness on
the baseline source to reproduce that probe, with --output probe --trace.
Diagnostic and comparison timings have different profiling/iteration contracts.

The frozen Python regression test precedes a later import-only style change.
All production and benchmark Go inputs match the final working tree.
