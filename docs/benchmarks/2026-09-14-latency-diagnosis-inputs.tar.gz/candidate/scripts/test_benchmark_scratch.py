import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from benchmark_snapshot_integration import benchmark_scratch, main


class BenchmarkScratchTests(unittest.TestCase):
    def test_campaign_failure_retains_status_and_log(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "results"

            def fail(args, roots, cases, output, env, report, scratch):
                (scratch / "benchmark.test").write_text("binary")
                (output / "run.txt").write_text("partial output")
                report["active"] = dict(variant="baseline", round=0, case="push")
                raise RuntimeError("injected campaign failure")

            argv = ["benchmark", "--baseline", directory, "--output", str(output), "--revision", "test"]
            with patch("sys.argv", argv), patch("benchmark_snapshot_integration.run_campaign", fail):
                with self.assertRaisesRegex(RuntimeError, "injected campaign failure"):
                    main()
            import json
            report = json.loads((output / "report.json").read_text())
            self.assertEqual(report["status"], "failed")
            self.assertEqual(report["active"]["case"], "push")
            self.assertEqual((output / "run.txt").read_text(), "partial output")
            self.assertEqual(sorted(p.name for p in output.iterdir()), ["report.json", "run.txt"])

    def test_failure_removes_scratch_but_preserves_diagnostics(self):
        for failure in (RuntimeError, KeyboardInterrupt):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory:
                output = Path(directory)
                log = output / "run.txt"
                log.write_text("partial output")
                outside = output / "retained"
                outside.mkdir()
                (outside / "report.json").write_text("{}")
                with self.assertRaises(failure):
                    with benchmark_scratch(output) as scratch:
                        locked = scratch / "restricted"
                        locked.mkdir()
                        (locked / "body").write_text("fixture")
                        (scratch / "external").symlink_to(outside, target_is_directory=True)
                        (scratch / "benchmark.test").write_text("binary")
                        os.chmod(locked, 0)
                        raise failure("injected failure")
                self.assertFalse(scratch.exists())
                self.assertEqual(log.read_text(), "partial output")
                self.assertEqual((outside / "report.json").read_text(), "{}")


if __name__ == "__main__":
    unittest.main()
